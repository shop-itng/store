export type UserRole = 'buyer' | 'seller' | 'admin';
export type AdminSubRole = 'moderator' | 'finance' | 'support';

export type Campus =
  | 'UNILAG (Akoka)'
  | 'UNILORIN'
  | 'UI (Ibadan)'
  | 'OAU (Ile-Ife)'
  | 'Covenant Univ'
  | 'UNN (Nsukka)'
  | 'LASU (Ojo)'
  | 'FUTA (Akure)'
  | 'ABU (Zaria)'
  | 'All Campuses';

export interface SellerProfile {
  id: string;
  shopName: string;
  bio: string;
  campus: Campus;
  logoUrl?: string;
  bannerUrl?: string;
  socialLinks?: {
    instagram?: string;
    whatsappPreview?: string;
    tiktok?: string;
  };
  isVerifiedSeller: boolean;
  verificationStatus: 'pending_approval' | 'approved' | 'rejected';
  under18: boolean;
  guardianConsent: boolean;
  guardianName?: string;
  guardianPhone?: string;
  badges: ('verified' | 'fast_responder' | 'sales_10' | 'top_rated')[];
  level: number; // 1 to 5
  rating: number;
  reviewCount: number;
  salesCount: number;
  viewsCount: number;
  vacationMode: boolean;
  joinedDate: string;
}

export interface User {
  id: string;
  email: string;
  phone: string;
  name: string;
  role: UserRole;
  adminSubRole?: AdminSubRole;
  isVerifiedEmail: boolean;
  isVerifiedPhone: boolean;
  avatarUrl?: string;
  sellerProfile?: SellerProfile;
  savedDeliveryArea?: string;
}

export type ProductCategory =
  | 'all'
  | 'beads'
  | 'fragrance'
  | 'bags'
  | 'fashion'
  | 'decor'
  | 'crafts';

export interface ProductCustomization {
  allowsCustomName?: boolean;
  availableColors?: string[];
  availableSizes?: string[];
  notesPrompt?: string;
}

export interface DeliverySetting {
  allowsPickup: boolean;
  pickupLocation: string;
  pickupFee: number;
  allowsLocalDelivery: boolean;
  localDeliveryFee: number;
  minOrderForDelivery: number;
}

export interface ProductReview {
  id: string;
  productId: string;
  buyerMaskedId: string; // e.g. "Buyer #7821" for anti-bypass privacy
  rating: number;
  comment: string;
  date: string;
  verifiedPurchase: boolean;
}

export interface Product {
  id: string;
  sellerId: string;
  sellerShopName: string;
  sellerCampus: Campus;
  sellerBadges: ('verified' | 'fast_responder' | 'sales_10' | 'top_rated')[];
  title: string;
  description: string;
  category: ProductCategory;
  sellerPrice: number; // What seller enters & earns
  serviceFee: number; // Shop It buyer protection fee
  displayPrice: number; // sellerPrice + serviceFee
  images: string[];
  stock: number;
  rating: number;
  reviewCount: number;
  reviews: ProductReview[];
  customization?: ProductCustomization;
  delivery: DeliverySetting;
  isSoldOut: boolean;
  isNewArrival: boolean;
  createdAt: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedSize?: string;
  customNameText?: string;
  deliveryMethod: 'pickup' | 'local_delivery';
}

export type OrderStatus =
  | 'paid'
  | 'packed'
  | 'shipped'
  | 'delivered'
  | 'completed'
  | 'cancelled'
  | 'disputed';

export interface OrderItem {
  productId: string;
  title: string;
  image: string;
  sellerId: string;
  sellerShopName: string;
  sellerCampus: Campus;
  quantity: number;
  sellerPrice: number;
  serviceFee: number;
  displayPrice: number;
  selectedColor?: string;
  selectedSize?: string;
  customNameText?: string;
  deliveryMethod: 'pickup' | 'local_delivery';
  deliveryFee: number;
}

export interface Order {
  id: string; // e.g. "ORD-84192"
  buyerId: string;
  buyerMaskedId: string; // e.g. "Buyer #7821" for anti-bypass privacy
  buyerName?: string; // Visible only to admin, NOT seller!
  deliveryArea: string;
  pickupPoint?: string;
  items: OrderItem[];
  itemsSubtotal: number;
  serviceFeeTotal: number;
  deliveryTotal: number;
  discountTotal: number;
  couponCode?: string;
  grandTotal: number;
  status: OrderStatus;
  paymentMethod: 'paystack_card' | 'paystack_transfer' | 'flutterwave_card';
  paymentReference: string;
  packedPhotoUrl?: string; // Uploaded by seller before dispatch
  createdAt: string;
  packedAt?: string;
  shippedAt?: string;
  deliveredAt?: string;
  completedAt?: string;
  autoReleaseAt: string; // 5-day auto-release timer
  disputeReason?: string;
  hasReview: boolean;
}

export interface Coupon {
  code: string;
  discountAmount: number;
  minOrder: number;
  description: string;
}

export type WalletTransactionType =
  | 'sale_pending'
  | 'escrow_release'
  | 'withdrawal'
  | 'fee_deduction'
  | 'refund';

export interface WalletTransaction {
  id: string; // e.g. "TXN-91024"
  type: WalletTransactionType;
  amount: number;
  fee: number;
  balanceAfter: number;
  status: 'pending' | 'completed' | 'held_for_review' | 'failed';
  description: string;
  reference: string;
  payoutBank?: string;
  payoutAccountNumber?: string;
  payoutAccountName?: string;
  createdAt: string;
}

export interface PayoutAccount {
  id: string;
  bankCode: string;
  bankName: string; // Opay, PalmPay, Kuda, GTBank, Access Bank, Zenith
  accountNumber: string;
  accountName: string;
  isVerified: boolean;
  coolingPeriodEndsAt: string; // 24-hr cooling period
  createdAt: string;
}

export interface SellerWallet {
  sellerId: string;
  pendingBalance: number;
  availableBalance: number;
  totalWithdrawn: number;
  isFrozen: boolean;
  freezeReason?: string;
  dailyLimit: number;
  withdrawnToday: number;
  firstWithdrawalCompleted: boolean;
  payoutAccounts: PayoutAccount[];
  activePayoutAccountId?: string;
  transactions: WalletTransaction[];
}

export interface SecuritySession {
  id: string;
  device: string;
  ip: string;
  location: string;
  lastActive: string;
  isCurrent: boolean;
}

export interface SecurityProfile {
  twoFactorEnabled: boolean;
  loginAlertsEnabled: boolean;
  failedLoginAttempts: number;
  isAccountLocked: boolean;
  sessions: SecuritySession[];
}

export interface FeeSettings {
  tierMode: 'tiered' | 'flat';
  flatFee: number;
  tierLowFee: number; // Under ₦2,000 -> ₦200
  tierMidFee: number; // ₦2,000 - ₦10,000 -> ₦500
  tierHighPercentage: number; // Above ₦10,000 -> 5%
  firstMonthPromoFree: boolean;
  withdrawalFeeRule: {
    freeThreshold: number; // e.g. Free above ₦5,000, ₦50 below
    flatFeeBelowThreshold: number;
  };
}

// ==========================================
// PHASE 3: LOCKED CHAT & PRIVACY ANTI-BYPASS
// ==========================================

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderRole: 'buyer' | 'seller' | 'system' | 'admin';
  senderMaskedName: string; // e.g. "Buyer #7821" or "Amaka Beads & Charms"
  senderId: string;
  content: string; // [blocked] if bypass attempt
  originalContent?: string;
  isBlockedBypass?: boolean;
  blockedTokens?: string[];
  timestamp: string;
  isQuickReply?: boolean;
  customOrderDetails?: {
    color?: string;
    size?: string;
    customName?: string;
    notes?: string;
  };
}

export interface Conversation {
  id: string;
  orderId?: string;
  productId?: string;
  productTitle?: string;
  productImage?: string;
  buyerId: string;
  buyerMaskedId: string;
  sellerId: string;
  sellerShopName: string;
  lastMessage: string;
  lastMessageAt: string;
  unreadBuyer: number;
  unreadSeller: number;
  isChatLocked?: boolean;
  bypassViolationsCount: number;
}

// ==========================================
// PHASE 3: ADMIN & DISPUTE RESOLUTION TYPES
// ==========================================

export interface DisputeTicket {
  id: string;
  orderId: string;
  buyerMaskedId: string;
  buyerName?: string; // Visible only to Admin
  sellerId: string;
  sellerShopName: string;
  reason: string;
  description: string;
  evidencePhotoUrl?: string;
  sellerPackedPhotoUrl?: string;
  amountHeldInEscrow: number;
  status: 'open' | 'resolved_refunded' | 'resolved_released' | 'resolved_partial';
  refundAmount?: number;
  resolutionNotes?: string;
  createdAt: string;
  resolvedAt?: string;
}

export interface SellerVerificationRequest {
  id: string;
  sellerId: string;
  shopName: string;
  ownerName: string;
  campus: Campus;
  idType: 'student_id' | 'nin' | 'voters_card';
  idNumber: string;
  idCardPhotoUrl: string;
  under18: boolean;
  guardianName?: string;
  guardianPhone?: string;
  guardianConsentLetterUrl?: string;
  submittedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  notes?: string;
}

export interface AntiBypassFlag {
  id: string;
  conversationId: string;
  senderId: string;
  senderRole: 'buyer' | 'seller';
  senderMaskedName: string;
  offendingText: string;
  maskedText: string;
  detectedPatterns: string[];
  timestamp: string;
  status: 'warning_issued' | 'chat_locked' | 'account_frozen' | 'reviewed';
}

