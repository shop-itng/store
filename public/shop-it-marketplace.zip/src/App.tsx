import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { MobileBottomNav } from './components/MobileBottomNav';
import { RoleSwitcherBar } from './components/RoleSwitcherBar';
import { LowDataBanner } from './components/LowDataBanner';
import { HeroBanner } from './components/HeroBanner';
import { TypoSearchBar } from './components/TypoSearchBar';
import { ProductCard } from './components/ProductCard';
import { ProductDetailView } from './components/ProductDetailView';
import { SellerShopView } from './components/SellerShopView';
import { SellerDashboard } from './components/SellerDashboard';
import { WishlistView } from './components/WishlistView';
import { CartView } from './components/CartView';
import { OrdersView } from './components/OrdersView';
import { AdminPanel } from './components/AdminPanel';
import { LockedChatView } from './components/LockedChatView';
import { ReportProblemModal } from './components/ReportProblemModal';
import { CheckoutModal } from './components/CheckoutModal';
import { AuthModal } from './components/AuthModal';
import { ToastContainer } from './components/ToastContainer';
import { Footer } from './components/Footer';
import { Sparkles, Store, ShieldCheck, MapPin, Star, ArrowRight, PackageOpen } from 'lucide-react';

const MarketplaceContent: React.FC = () => {
  const {
    activeView,
    setActiveView,
    selectedProductId,
    selectedSellerId,
    products,
    filteredProducts,
    sellers,
    openSellerShop,
    resetFilters,
  } = useApp();

  const selectedProduct = products.find(p => p.id === selectedProductId);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-20 md:pb-0">
      {/* Role Switcher Toolbar for evaluating all user roles & modes */}
      <RoleSwitcherBar />

      {/* Main Top Header */}
      <Header />

      {/* Low-data mode notice (if enabled) */}
      <LowDataBanner />

      {/* Main View Router */}
      <main className="flex-1">
        {activeView === 'catalog' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
            {/* Hero Banner */}
            <HeroBanner />

            {/* Typo-tolerant Search & Filter Bar */}
            <TypoSearchBar />

            {/* Product Feed Grid */}
            <section className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-slate-900">
                    Handmade Crafts on Campus
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Showing {filteredProducts.length} unique handcrafted items in Nigerian Naira (₦)
                  </p>
                </div>
              </div>

              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              ) : (
                <div className="bg-white rounded-2xl border border-slate-200 p-12 text-center max-w-md mx-auto space-y-3">
                  <PackageOpen className="w-10 h-10 text-slate-300 mx-auto" />
                  <h3 className="text-base font-bold text-slate-900">No crafts found</h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    We couldn't find items matching your search or filters. Try checking your spelling or clearing filters.
                  </p>
                  <button
                    onClick={resetFilters}
                    className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-lg hover:bg-slate-800 transition-colors"
                  >
                    Clear All Filters
                  </button>
                </div>
              )}
            </section>

            {/* Featured Student Artisans Spotlight Section */}
            <section className="pt-8 border-t border-slate-200/80 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    Featured Student Makers
                  </h3>
                  <p className="text-xs text-slate-500">
                    Support verified teen and university entrepreneurs creating crafts between lectures.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {sellers.map(seller => (
                  <div
                    key={seller.id}
                    onClick={() => openSellerShop(seller.id)}
                    className="bg-white p-4 rounded-xl border border-slate-200/90 hover:border-slate-300 hover:shadow-xs transition-all cursor-pointer flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-xl bg-slate-100 overflow-hidden shrink-0 border border-slate-200">
                          {seller.logoUrl ? (
                            <img
                              src={seller.logoUrl}
                              alt={seller.shopName}
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center font-bold text-emerald-800 bg-emerald-100 text-sm">
                              {seller.shopName[0]}
                            </div>
                          )}
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-xs sm:text-sm font-bold text-slate-900 truncate">
                            {seller.shopName}
                          </h4>
                          <div className="text-[11px] text-slate-500 truncate flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                            <span>{seller.campus}</span>
                          </div>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                        {seller.bio}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs mt-3">
                      <div className="flex items-center gap-1 font-semibold text-slate-800">
                        <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                        <span className="font-mono-numbers">{seller.rating.toFixed(1)}</span>
                        <span className="text-[11px] text-slate-400 font-normal">({seller.salesCount} sales)</span>
                      </div>
                      <span className="text-emerald-700 font-semibold text-[11px] flex items-center gap-0.5">
                        <span>Visit Shop</span>
                        <ArrowRight className="w-3 h-3" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}

        {activeView === 'product_detail' && selectedProduct && (
          <ProductDetailView
            product={selectedProduct}
            onBack={() => setActiveView('catalog')}
          />
        )}

        {activeView === 'seller_shop' && selectedSellerId && (
          <SellerShopView
            sellerId={selectedSellerId}
            onBack={() => setActiveView('catalog')}
          />
        )}

        {activeView === 'seller_dashboard' && <SellerDashboard />}

        {activeView === 'wishlist' && <WishlistView />}

        {activeView === 'cart' && <CartView />}

        {activeView === 'orders' && <OrdersView />}
        {activeView === 'admin' && <AdminPanel />}
        {activeView === 'chat' && <LockedChatView />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Mobile Bottom Thumb Navigation */}
      <MobileBottomNav />

      {/* Authentication and Onboarding Modal */}
      <AuthModal />

      {/* Paystack Escrow Checkout Modal */}
      <CheckoutModal />

      {/* Escrow Dispute & Problem Modal */}
      <ReportProblemModal />

      {/* Toast Notifications */}
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MarketplaceContent />
    </AppProvider>
  );
}
