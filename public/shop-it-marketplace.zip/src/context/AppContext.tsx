import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  Product,
  SellerProfile,
  CartItem,
  Campus,
  ProductCategory,
  UserRole,
  Order,
  OrderStatus,
  Coupon,
  SellerWallet,
  PayoutAccount,
  WalletTransaction,
  SecurityProfile,
  ChatMessage,
  Conversation,
  DisputeTicket,
  SellerVerificationRequest,
  AntiBypassFlag,
  AdminSubRole,
  FeeSettings,
} from '../types';
import {
  INITIAL_PRODUCTS,
  INITIAL_SELLERS,
  DEMO_USERS,
  INITIAL_ORDERS,
  VALID_COUPONS,
  INITIAL_WALLETS,
  INITIAL_SECURITY_PROFILES,
  INITIAL_CONVERSATIONS,
  INITIAL_MESSAGES,
  INITIAL_VERIFICATION_REQUESTS,
  INITIAL_DISPUTES,
  INITIAL_ANTI_BYPASS_FLAGS,
} from '../data/mockData';
import { getPricingBreakdown, DEFAULT_FEE_SETTINGS } from '../utils/pricing';
import { filterAntiBypass } from '../utils/antiBypass';

interface NotificationItem {
  id: string;
  message: string;
  type: 'success' | 'info' | 'error';
}

interface AppContextType {
  currentUser: User | null;
  switchRole: (role: UserRole) => void;
  login: (userData: Partial<User>) => void;
  logout: () => void;
  isAuthModalOpen: boolean;
  openAuthModal: (tab?: 'login' | 'signup' | 'seller_register') => void;
  closeAuthModal: () => void;
  authTab: 'login' | 'signup' | 'otp' | 'seller_register';
  setAuthTab: (tab: 'login' | 'signup' | 'otp' | 'seller_register') => void;
  pendingAuthData: any;
  setPendingAuthData: (data: any) => void;
  verifyOtp: (code: string) => boolean;
  submitSellerRegistration: (sellerData: {
    shopName: string;
    campus: Campus;
    bio: string;
    under18: boolean;
    guardianName?: string;
    guardianPhone?: string;
  }) => void;

  // Catalog & Products
  products: Product[];
  filteredProducts: Product[];
  addProduct: (newProd: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewCount' | 'reviews'>) => void;
  updateProduct: (id: string, updates: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  toggleProductStock: (id: string) => void;

  // Sellers
  sellers: SellerProfile[];
  getSellerById: (id: string) => SellerProfile | undefined;
  currentSeller: SellerProfile | null;
  toggleVacationMode: (sellerId: string) => void;

  // Search & Filters
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedCategory: ProductCategory;
  setSelectedCategory: (cat: ProductCategory) => void;
  selectedCampus: Campus;
  setSelectedCampus: (campus: Campus) => void;
  priceFilter: 'all' | 'under2k' | '2k-5k' | '5k-10k' | 'above10k';
  setPriceFilter: (p: 'all' | 'under2k' | '2k-5k' | '5k-10k' | 'above10k') => void;
  sortBy: 'newest' | 'price_asc' | 'price_desc' | 'top_rated';
  setSortBy: (s: 'newest' | 'price_asc' | 'price_desc' | 'top_rated') => void;
  resetFilters: () => void;

  // Navigation views
  activeView: 'catalog' | 'product_detail' | 'seller_shop' | 'seller_dashboard' | 'wishlist' | 'cart' | 'orders' | 'admin' | 'chat';
  setActiveView: (view: 'catalog' | 'product_detail' | 'seller_shop' | 'seller_dashboard' | 'wishlist' | 'cart' | 'orders' | 'admin' | 'chat') => void;
  selectedProductId: string | null;
  selectedSellerId: string | null;
  openProduct: (id: string) => void;
  openSellerShop: (sellerId: string) => void;

  // Wishlist & Cart
  wishlist: string[];
  toggleWishlist: (productId: string) => void;
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;
  cartCount: number;

  // Orders & Escrow
  orders: Order[];
  placeOrder: (orderData: Omit<Order, 'id' | 'createdAt' | 'autoReleaseAt' | 'hasReview'>) => Order;
  updateOrderStatus: (
    orderId: string,
    status: OrderStatus,
    extra?: { packedPhotoUrl?: string; disputeReason?: string }
  ) => void;
  confirmItemReceived: (orderId: string) => void;
  cancelOrder: (orderId: string) => void;
  openDispute: (orderId: string, reason: string) => void;
  submitOrderReview: (orderId: string, productId: string, rating: number, comment: string) => void;
  buyerActiveOrdersCount: number;

  // Phase 3: Locked Chat & Privacy Anti-Bypass
  conversations: Conversation[];
  messages: Record<string, ChatMessage[]>;
  activeConversationId: string | null;
  setActiveConversationId: (id: string | null) => void;
  openChat: (conversationId?: string, targetInfo?: { orderId?: string; productId?: string; sellerId?: string }) => void;
  sendMessage: (conversationId: string, content: string, customOrder?: any) => { success: boolean; isBlocked?: boolean; warning?: string };

  // Phase 3: Admin Command Center (Moderator, Finance, Support)
  adminSubRole: AdminSubRole;
  setAdminSubRole: (subRole: AdminSubRole) => void;
  verificationRequests: SellerVerificationRequest[];
  updateVerificationRequest: (id: string, status: 'approved' | 'rejected', notes?: string) => void;
  disputes: DisputeTicket[];
  resolveDispute: (disputeId: string, resolution: 'refund_full' | 'release_seller' | 'partial', amount?: number, notes?: string) => void;
  antiBypassFlags: AntiBypassFlag[];
  updateFlagStatus: (flagId: string, action: 'warn' | 'lock_chat' | 'freeze_account' | 'dismiss') => void;
  feeSettings: FeeSettings;
  updateFeeSettings: (settings: Partial<FeeSettings>) => void;

  // Phase 3: Report Problem Modal
  isReportProblemModalOpen: boolean;
  activeReportOrderId: string | null;
  openReportProblemModal: (orderId: string) => void;
  closeReportProblemModal: () => void;

  // Seller Wallet & Payouts
  wallets: Record<string, SellerWallet>;
  currentWallet: SellerWallet | null;
  requestWithdrawal: (amount: number, payoutAccountId: string, otpCode: string) => boolean;
  addPayoutAccount: (bankCode: string, bankName: string, accountNumber: string, accountName: string) => boolean;
  toggleWalletFreeze: (sellerId: string, freeze: boolean, reason?: string) => void;

  // Security Hardening
  securityProfile: SecurityProfile;
  toggleTwoFactor: () => void;
  revokeSession: (sessionId: string) => void;

  // Checkout modal & coupons
  isCheckoutModalOpen: boolean;
  openCheckoutModal: () => void;
  closeCheckoutModal: () => void;
  appliedCoupon: Coupon | null;
  applyCoupon: (code: string, currentTotal: number) => boolean;
  removeCoupon: () => void;

  // Low-Data Mode & Language
  lowDataMode: boolean;
  toggleLowDataMode: () => void;
  language: 'en' | 'pidgin';
  toggleLanguage: () => void;

  // Toast Notifications
  notifications: NotificationItem[];
  notify: (message: string, type?: 'success' | 'info' | 'error') => void;
  dismissNotification: (id: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence helpers
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('shopit_current_user');
    return saved ? JSON.parse(saved) : DEMO_USERS.buyer;
  });

  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('shopit_products');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  const [sellers, setSellers] = useState<SellerProfile[]>(() => {
    const saved = localStorage.getItem('shopit_sellers');
    return saved ? JSON.parse(saved) : INITIAL_SELLERS;
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('shopit_wishlist');
    return saved ? JSON.parse(saved) : ['prod_1', 'prod_4'];
  });

  const [cart, setCart] = useState<CartItem[]>(() => {
    const saved = localStorage.getItem('shopit_cart');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('shopit_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [wallets, setWallets] = useState<Record<string, SellerWallet>>(() => {
    const saved = localStorage.getItem('shopit_wallets');
    return saved ? JSON.parse(saved) : INITIAL_WALLETS;
  });

  const [securityProfiles, setSecurityProfiles] = useState<Record<string, SecurityProfile>>(() => {
    const saved = localStorage.getItem('shopit_security_profiles');
    return saved ? JSON.parse(saved) : INITIAL_SECURITY_PROFILES;
  });

  const [lowDataMode, setLowDataMode] = useState<boolean>(() => {
    return localStorage.getItem('shopit_low_data') === 'true';
  });

  const [language, setLanguage] = useState<'en' | 'pidgin'>('en');

  // Checkout & Coupon states
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [selectedCampus, setSelectedCampus] = useState<Campus>('All Campuses');
  const [priceFilter, setPriceFilter] = useState<'all' | 'under2k' | '2k-5k' | '5k-10k' | 'above10k'>('all');
  const [sortBy, setSortBy] = useState<'newest' | 'price_asc' | 'price_desc' | 'top_rated'>('newest');

  // Navigation states
  const [activeView, setActiveView] = useState<'catalog' | 'product_detail' | 'seller_shop' | 'seller_dashboard' | 'wishlist' | 'cart' | 'orders' | 'admin' | 'chat'>('catalog');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [selectedSellerId, setSelectedSellerId] = useState<string | null>(null);

  // Phase 3: Locked Chat States
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    const saved = localStorage.getItem('shopit_conversations');
    return saved ? JSON.parse(saved) : INITIAL_CONVERSATIONS;
  });
  const [messages, setMessages] = useState<Record<string, ChatMessage[]>>(() => {
    const saved = localStorage.getItem('shopit_messages');
    return saved ? JSON.parse(saved) : INITIAL_MESSAGES;
  });
  const [activeConversationId, setActiveConversationId] = useState<string | null>('conv_1');

  // Phase 3: Admin & Moderation States
  const [adminSubRole, setAdminSubRole] = useState<AdminSubRole>('moderator');
  const [verificationRequests, setVerificationRequests] = useState<SellerVerificationRequest[]>(() => {
    const saved = localStorage.getItem('shopit_verification_requests');
    return saved ? JSON.parse(saved) : INITIAL_VERIFICATION_REQUESTS;
  });
  const [disputes, setDisputes] = useState<DisputeTicket[]>(() => {
    const saved = localStorage.getItem('shopit_disputes');
    return saved ? JSON.parse(saved) : INITIAL_DISPUTES;
  });
  const [antiBypassFlags, setAntiBypassFlags] = useState<AntiBypassFlag[]>(() => {
    const saved = localStorage.getItem('shopit_anti_bypass_flags');
    return saved ? JSON.parse(saved) : INITIAL_ANTI_BYPASS_FLAGS;
  });
  const [feeSettings, setFeeSettings] = useState<FeeSettings>(() => {
    const saved = localStorage.getItem('shopit_fee_settings');
    return saved ? JSON.parse(saved) : DEFAULT_FEE_SETTINGS;
  });

  // Phase 3: Report Problem Modal State
  const [isReportProblemModalOpen, setIsReportProblemModalOpen] = useState(false);
  const [activeReportOrderId, setActiveReportOrderId] = useState<string | null>(null);

  // Auth modal states
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authTab, setAuthTab] = useState<'login' | 'signup' | 'otp' | 'seller_register'>('login');
  const [pendingAuthData, setPendingAuthData] = useState<any>(null);

  // Notifications
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Sync state to LocalStorage
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('shopit_current_user', JSON.stringify(currentUser));
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('shopit_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('shopit_sellers', JSON.stringify(sellers));
  }, [sellers]);

  useEffect(() => {
    localStorage.setItem('shopit_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('shopit_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('shopit_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('shopit_wallets', JSON.stringify(wallets));
  }, [wallets]);

  useEffect(() => {
    localStorage.setItem('shopit_security_profiles', JSON.stringify(securityProfiles));
  }, [securityProfiles]);

  useEffect(() => {
    localStorage.setItem('shopit_low_data', String(lowDataMode));
  }, [lowDataMode]);

  useEffect(() => {
    localStorage.setItem('shopit_conversations', JSON.stringify(conversations));
  }, [conversations]);

  useEffect(() => {
    localStorage.setItem('shopit_messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('shopit_verification_requests', JSON.stringify(verificationRequests));
  }, [verificationRequests]);

  useEffect(() => {
    localStorage.setItem('shopit_disputes', JSON.stringify(disputes));
  }, [disputes]);

  useEffect(() => {
    localStorage.setItem('shopit_anti_bypass_flags', JSON.stringify(antiBypassFlags));
  }, [antiBypassFlags]);

  useEffect(() => {
    localStorage.setItem('shopit_fee_settings', JSON.stringify(feeSettings));
  }, [feeSettings]);

  const notify = (message: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = Date.now().toString() + Math.random().toString().slice(2, 5);
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      dismissNotification(id);
    }, 4000);
  };

  const dismissNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const switchRole = (role: UserRole) => {
    if (role === 'buyer') {
      setCurrentUser(DEMO_USERS.buyer);
      setActiveView('catalog');
      notify('Switched to Buyer view (Tobi Adebisi)', 'info');
    } else if (role === 'seller') {
      setCurrentUser(DEMO_USERS.seller);
      setActiveView('seller_dashboard');
      notify('Switched to Student Seller view (Amaka Beads)', 'info');
    } else if (role === 'admin') {
      setCurrentUser(DEMO_USERS.admin);
      setActiveView('admin');
      notify('Switched to Admin Command Center (Moderator / Finance / Support)', 'info');
    }
  };

  const login = (userData: Partial<User>) => {
    const newUser: User = {
      id: userData.id || `user_${Date.now()}`,
      name: userData.name || 'Student Shopper',
      email: userData.email || 'user@campus.ng',
      phone: userData.phone || '+2348000000000',
      role: userData.role || 'buyer',
      isVerifiedEmail: true,
      isVerifiedPhone: true,
      savedDeliveryArea: userData.savedDeliveryArea || 'UNILAG (Akoka)',
      sellerProfile: userData.sellerProfile,
    };
    setCurrentUser(newUser);
    notify(`Welcome back, ${newUser.name}!`, 'success');
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('shopit_current_user');
    notify('Logged out successfully', 'info');
  };

  const openAuthModal = (tab: 'login' | 'signup' | 'seller_register' = 'login') => {
    setAuthTab(tab);
    setIsAuthModalOpen(true);
  };

  const closeAuthModal = () => {
    setIsAuthModalOpen(false);
    setPendingAuthData(null);
  };

  const verifyOtp = (code: string) => {
    if (code.trim().length === 4) {
      if (pendingAuthData) {
        if (pendingAuthData.role === 'seller') {
          setAuthTab('seller_register');
          notify('Phone verified! Complete your student artisan profile.', 'success');
          return true;
        } else {
          login({
            name: pendingAuthData.name,
            email: pendingAuthData.email,
            phone: pendingAuthData.phone,
            role: 'buyer',
          });
          closeAuthModal();
          return true;
        }
      }
    }
    notify('Please enter the 4-digit code (e.g., 1234)', 'error');
    return false;
  };

  const submitSellerRegistration = (sellerData: {
    shopName: string;
    campus: Campus;
    bio: string;
    under18: boolean;
    guardianName?: string;
    guardianPhone?: string;
  }) => {
    const newSellerId = `seller_${Date.now()}`;
    const newSeller: SellerProfile = {
      id: newSellerId,
      shopName: sellerData.shopName,
      bio: sellerData.bio,
      campus: sellerData.campus,
      isVerifiedSeller: true,
      verificationStatus: 'approved',
      under18: sellerData.under18,
      guardianConsent: sellerData.under18,
      guardianName: sellerData.guardianName,
      guardianPhone: sellerData.guardianPhone,
      badges: ['verified'],
      level: 1,
      rating: 5.0,
      reviewCount: 0,
      salesCount: 0,
      viewsCount: 0,
      vacationMode: false,
      joinedDate: 'Today',
    };

    setSellers(prev => [newSeller, ...prev]);

    // Initialize new seller wallet
    const newWallet: SellerWallet = {
      sellerId: newSellerId,
      pendingBalance: 0,
      availableBalance: 0,
      totalWithdrawn: 0,
      isFrozen: false,
      dailyLimit: 50000,
      withdrawnToday: 0,
      firstWithdrawalCompleted: false,
      payoutAccounts: [],
      transactions: [],
    };
    setWallets(prev => ({ ...prev, [newSellerId]: newWallet }));

    const sellerUser: User = {
      id: newSellerId,
      name: pendingAuthData?.name || sellerData.shopName,
      email: pendingAuthData?.email || 'artisan@campus.ng',
      phone: pendingAuthData?.phone || '+2348000000000',
      role: 'seller',
      isVerifiedEmail: true,
      isVerifiedPhone: true,
      sellerProfile: newSeller,
      savedDeliveryArea: sellerData.campus,
    };

    setCurrentUser(sellerUser);
    closeAuthModal();
    setActiveView('seller_dashboard');
    notify(`Shop "${sellerData.shopName}" registered! Welcome to Shop It.`, 'success');
  };

  const addProduct = (newProd: Omit<Product, 'id' | 'createdAt' | 'rating' | 'reviewCount' | 'reviews'>) => {
    const id = `prod_${Date.now()}`;
    const pricing = getPricingBreakdown(newProd.sellerPrice);
    const product: Product = {
      ...newProd,
      id,
      serviceFee: pricing.serviceFee,
      displayPrice: pricing.displayPrice,
      rating: 5.0,
      reviewCount: 0,
      reviews: [],
      createdAt: new Date().toISOString().split('T')[0],
      isSoldOut: newProd.stock <= 0,
      isNewArrival: true,
    };
    setProducts(prev => [product, ...prev]);
    notify(`Product "${product.title}" listed successfully!`, 'success');
  };

  const updateProduct = (id: string, updates: Partial<Product>) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.id === id) {
          const updated = { ...p, ...updates };
          if (updates.sellerPrice !== undefined) {
            const pricing = getPricingBreakdown(updates.sellerPrice);
            updated.sellerPrice = pricing.sellerPrice;
            updated.serviceFee = pricing.serviceFee;
            updated.displayPrice = pricing.displayPrice;
          }
          if (updates.stock !== undefined) {
            updated.isSoldOut = updates.stock <= 0;
          }
          return updated;
        }
        return p;
      })
    );
    notify('Product updated', 'success');
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
    notify('Product removed', 'info');
  };

  const toggleProductStock = (id: string) => {
    setProducts(prev =>
      prev.map(p => {
        if (p.id === id) {
          const newStock = p.stock > 0 ? 0 : 5;
          return { ...p, stock: newStock, isSoldOut: newStock === 0 };
        }
        return p;
      })
    );
  };

  const toggleVacationMode = (sellerId: string) => {
    setSellers(prev =>
      prev.map(s => {
        if (s.id === sellerId) {
          const newMode = !s.vacationMode;
          notify(newMode ? 'Vacation mode activated. Your shop is paused.' : 'Vacation mode disabled. Your shop is open!', 'info');
          return { ...s, vacationMode: newMode };
        }
        return s;
      })
    );
    if (currentUser?.sellerProfile?.id === sellerId) {
      setCurrentUser(prev => prev ? {
        ...prev,
        sellerProfile: prev.sellerProfile ? {
          ...prev.sellerProfile,
          vacationMode: !prev.sellerProfile.vacationMode
        } : undefined
      } : null);
    }
  };

  const getSellerById = (id: string) => sellers.find(s => s.id === id);

  const currentSeller = currentUser?.sellerProfile || (currentUser?.role === 'seller' ? sellers[0] : null);

  const currentWallet: SellerWallet | null = currentSeller
    ? wallets[currentSeller.id] || wallets['seller_amaka'] || null
    : null;

  const currentSecurityProfile: SecurityProfile = currentUser
    ? securityProfiles[currentUser.id] || securityProfiles['seller_amaka'] || securityProfiles['user_tobi_buyer']
    : securityProfiles['user_tobi_buyer'];

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => {
      const exists = prev.includes(productId);
      if (exists) {
        notify('Removed from wishlist', 'info');
        return prev.filter(id => id !== productId);
      } else {
        notify('Saved to wishlist!', 'success');
        return [...prev, productId];
      }
    });
  };

  const addToCart = (item: CartItem) => {
    setCart(prev => {
      const existingIdx = prev.findIndex(i => i.product.id === item.product.id);
      if (existingIdx >= 0) {
        const updated = [...prev];
        updated[existingIdx].quantity += item.quantity;
        return updated;
      }
      return [...prev, item];
    });
    notify(`Added "${item.product.title.slice(0, 24)}..." to cart!`, 'success');
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(i => i.id !== cartItemId));
    notify('Item removed from cart', 'info');
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Coupons
  const applyCoupon = (code: string, currentTotal: number): boolean => {
    const cleanCode = code.trim().toUpperCase();
    const coupon = VALID_COUPONS.find(c => c.code === cleanCode);
    if (!coupon) {
      notify('Invalid promo code. Try "CAMPUSLOVE" or "FIRSTCRAFT"', 'error');
      return false;
    }
    if (currentTotal < coupon.minOrder) {
      notify(`This coupon requires a minimum order of ₦${coupon.minOrder.toLocaleString()}`, 'error');
      return false;
    }
    setAppliedCoupon(coupon);
    notify(`Promo code ${coupon.code} applied: ₦${coupon.discountAmount.toLocaleString()} discount!`, 'success');
    return true;
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
    notify('Coupon removed', 'info');
  };

  // Orders and Escrow Management
  const placeOrder = (orderData: Omit<Order, 'id' | 'createdAt' | 'autoReleaseAt' | 'hasReview'>): Order => {
    const orderId = `ORD-${Math.floor(10000 + Math.random() * 90000)}`;
    const now = new Date();
    const autoRelease = new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000); // 5 days auto-release rule

    const newOrder: Order = {
      ...orderData,
      id: orderId,
      createdAt: now.toISOString(),
      autoReleaseAt: autoRelease.toISOString(),
      hasReview: false,
      status: 'paid', // Escrow begins
    };

    setOrders(prev => [newOrder, ...prev]);

    // Append-only ledger updates for each seller in the order
    setWallets(prevWallets => {
      const updated = { ...prevWallets };
      newOrder.items.forEach(item => {
        const sId = item.sellerId;
        const currentW = updated[sId] || {
          sellerId: sId,
          pendingBalance: 0,
          availableBalance: 0,
          totalWithdrawn: 0,
          isFrozen: false,
          dailyLimit: 50000,
          withdrawnToday: 0,
          firstWithdrawalCompleted: false,
          payoutAccounts: [],
          transactions: [],
        };

        const itemEarnings = item.sellerPrice * item.quantity;
        const newTxn: WalletTransaction = {
          id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
          type: 'sale_pending',
          amount: itemEarnings,
          fee: item.serviceFee * item.quantity,
          balanceAfter: currentW.availableBalance,
          status: 'pending',
          description: `New Escrow Payment · Order #${orderId} (${item.title})`,
          reference: orderId,
          createdAt: 'Just now',
        };

        updated[sId] = {
          ...currentW,
          pendingBalance: currentW.pendingBalance + itemEarnings,
          transactions: [newTxn, ...currentW.transactions],
        };
      });
      return updated;
    });

    clearCart();
    setAppliedCoupon(null);
    notify(`Order #${orderId} paid and held in Shop It Escrow!`, 'success');
    return newOrder;
  };

  const updateOrderStatus = (
    orderId: string,
    status: OrderStatus,
    extra?: { packedPhotoUrl?: string; disputeReason?: string }
  ) => {
    const now = new Date().toISOString();
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id === orderId) {
          const updated: Order = { ...ord, status };
          if (status === 'packed') {
            updated.packedAt = now;
            if (extra?.packedPhotoUrl) updated.packedPhotoUrl = extra.packedPhotoUrl;
          } else if (status === 'shipped') {
            updated.shippedAt = now;
          } else if (status === 'delivered') {
            updated.deliveredAt = now;
          } else if (status === 'completed') {
            updated.completedAt = now;
          } else if (status === 'disputed' && extra?.disputeReason) {
            updated.disputeReason = extra.disputeReason;
          }
          return updated;
        }
        return ord;
      })
    );

    if (status === 'packed') {
      notify('Order marked as Packed with photo verification!', 'success');
    } else if (status === 'shipped') {
      notify('Order dispatched/shipped to campus drop point!', 'info');
    } else if (status === 'delivered') {
      notify('Order delivered! Buyer notified to inspect.', 'info');
    }
  };

  const confirmItemReceived = (orderId: string) => {
    const ord = orders.find(o => o.id === orderId);
    if (!ord) return;

    updateOrderStatus(orderId, 'completed');

    // Move money from Pending Balance to Available Balance (Escrow release)
    setWallets(prevWallets => {
      const updated = { ...prevWallets };
      ord.items.forEach(item => {
        const sId = item.sellerId;
        const currentW = updated[sId] || updated['seller_amaka'];
        if (currentW) {
          const itemEarnings = item.sellerPrice * item.quantity;
          const newAvailable = currentW.availableBalance + itemEarnings;
          const newPending = Math.max(0, currentW.pendingBalance - itemEarnings);

          const newTxn: WalletTransaction = {
            id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
            type: 'escrow_release',
            amount: itemEarnings,
            fee: 0,
            balanceAfter: newAvailable,
            status: 'completed',
            description: `Escrow Released · Order #${orderId} confirmed by buyer`,
            reference: orderId,
            createdAt: 'Just now',
          };

          updated[sId] = {
            ...currentW,
            availableBalance: newAvailable,
            pendingBalance: newPending,
            transactions: [newTxn, ...currentW.transactions],
          };
        }
      });
      return updated;
    });

    notify('Item received confirmed! Escrow funds released to seller available balance.', 'success');
  };

  const cancelOrder = (orderId: string) => {
    const ord = orders.find(o => o.id === orderId);
    if (!ord) return;
    if (ord.status !== 'paid') {
      notify('Orders cannot be cancelled once the seller marks them as packed.', 'error');
      return;
    }
    updateOrderStatus(orderId, 'cancelled');

    // Remove from seller pending balance
    setWallets(prevWallets => {
      const updated = { ...prevWallets };
      ord.items.forEach(item => {
        const sId = item.sellerId;
        const currentW = updated[sId];
        if (currentW) {
          const itemEarnings = item.sellerPrice * item.quantity;
          updated[sId] = {
            ...currentW,
            pendingBalance: Math.max(0, currentW.pendingBalance - itemEarnings),
            transactions: [
              {
                id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
                type: 'refund',
                amount: itemEarnings,
                fee: 0,
                balanceAfter: currentW.availableBalance,
                status: 'completed',
                description: `Cancelled Order #${orderId} · Refunded to buyer`,
                reference: orderId,
                createdAt: 'Just now',
              },
              ...currentW.transactions,
            ],
          };
        }
      });
      return updated;
    });

    notify(`Order #${orderId} cancelled. ₦${ord.grandTotal.toLocaleString()} refunded automatically.`, 'success');
  };

  const openDispute = (orderId: string, reason: string) => {
    updateOrderStatus(orderId, 'disputed', { disputeReason: reason });
    const ord = orders.find(o => o.id === orderId);
    if (ord) {
      const newDispute: DisputeTicket = {
        id: `disp_${Date.now()}`,
        orderId,
        buyerMaskedId: ord.buyerMaskedId,
        buyerName: ord.buyerName || 'Tobi Adebisi',
        sellerId: ord.items[0]?.sellerId || 'seller_amaka',
        sellerShopName: ord.items[0]?.sellerShopName || 'Amaka Beads & Charms',
        reason,
        description: reason,
        sellerPackedPhotoUrl: ord.packedPhotoUrl,
        evidencePhotoUrl: 'https://images.unsplash.com/photo-1594035910387-fea47794261f?w=600&auto=format&fit=crop&q=80',
        amountHeldInEscrow: ord.grandTotal,
        status: 'open',
        createdAt: 'Just now',
      };
      setDisputes(prev => [newDispute, ...prev]);
    }
    notify('Dispute opened. Escrow release is frozen while moderation reviews.', 'error');
  };

  const submitOrderReview = (orderId: string, productId: string, rating: number, comment: string) => {
    const reviewId = `rev_${Date.now()}`;
    const newReview = {
      id: reviewId,
      productId,
      buyerMaskedId: currentUser?.name ? `Buyer #${Math.floor(1000 + Math.random() * 9000)}` : 'Verified Buyer',
      rating,
      comment,
      date: 'Just now',
      verifiedPurchase: true,
    };

    setProducts(prev =>
      prev.map(p => {
        if (p.id === productId) {
          const updatedReviews = [newReview, ...p.reviews];
          const newAvg = updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length;
          return {
            ...p,
            reviews: updatedReviews,
            reviewCount: updatedReviews.length,
            rating: Number(newAvg.toFixed(1)),
          };
        }
        return p;
      })
    );

    setOrders(prev =>
      prev.map(o => (o.id === orderId ? { ...o, hasReview: true } : o))
    );

    notify('Thank you for rating your campus artisan!', 'success');
  };

  // Phase 3: Seller Wallet & Withdrawal implementation
  const requestWithdrawal = (amount: number, payoutAccountId: string, otpCode: string): boolean => {
    if (!currentSeller) return false;
    const wallet = wallets[currentSeller.id] || wallets['seller_amaka'];
    if (!wallet) return false;

    if (wallet.isFrozen) {
      notify(`Wallet is frozen: ${wallet.freezeReason || 'Contact Admin'}`, 'error');
      return false;
    }

    if (otpCode.trim() !== '1234') {
      notify('Invalid withdrawal OTP code. Use demo code: 1234', 'error');
      return false;
    }

    if (amount < 1000) {
      notify('Minimum withdrawal is ₦1,000.', 'error');
      return false;
    }

    const payoutAccount = wallet.payoutAccounts.find(p => p.id === payoutAccountId);
    if (!payoutAccount) {
      notify('Selected payout account not found.', 'error');
      return false;
    }

    // Cooling period rule: new payout account cooling period
    const coolingEnd = new Date(payoutAccount.coolingPeriodEndsAt).getTime();
    if (Date.now() < coolingEnd) {
      notify('This payout account is in a 24-hour security cooling period.', 'error');
      return false;
    }

    // Fee rule from prompt: free above ₦5,000, flat ₦50 below
    const fee = amount >= DEFAULT_FEE_SETTINGS.withdrawalFeeRule.freeThreshold
      ? 0
      : DEFAULT_FEE_SETTINGS.withdrawalFeeRule.flatFeeBelowThreshold;

    const totalDeduction = amount + fee;

    if (wallet.availableBalance < totalDeduction) {
      notify(`Insufficient available balance. You need ₦${totalDeduction.toLocaleString()} (including ₦${fee} fee).`, 'error');
      return false;
    }

    const newBalance = wallet.availableBalance - totalDeduction;

    const txnId = `TXN-${Math.floor(10000 + Math.random() * 90000)}`;
    const newTxn: WalletTransaction = {
      id: txnId,
      type: 'withdrawal',
      amount,
      fee,
      balanceAfter: newBalance,
      status: wallet.firstWithdrawalCompleted ? 'completed' : 'held_for_review',
      description: `Payout to ${payoutAccount.bankName} · ${payoutAccount.accountNumber} (${payoutAccount.accountName})`,
      reference: `WTH_${Date.now()}`,
      payoutBank: payoutAccount.bankName,
      payoutAccountNumber: payoutAccount.accountNumber,
      payoutAccountName: payoutAccount.accountName,
      createdAt: 'Just now',
    };

    setWallets(prev => ({
      ...prev,
      [currentSeller.id]: {
        ...wallet,
        availableBalance: newBalance,
        totalWithdrawn: wallet.totalWithdrawn + amount,
        withdrawnToday: wallet.withdrawnToday + amount,
        firstWithdrawalCompleted: true,
        transactions: [newTxn, ...wallet.transactions],
      },
    }));

    notify(
      fee === 0
        ? `Withdrawal of ₦${amount.toLocaleString()} to ${payoutAccount.bankName} successful (Free above ₦5k)!`
        : `Withdrawal of ₦${amount.toLocaleString()} to ${payoutAccount.bankName} successful (₦50 network fee applied).`,
      'success'
    );
    notify(`SMS Alert: ₦${amount.toLocaleString()} transferred to ${payoutAccount.bankName} (${payoutAccount.accountNumber})`, 'info');
    return true;
  };

  const addPayoutAccount = (
    bankCode: string,
    bankName: string,
    accountNumber: string,
    accountName: string
  ): boolean => {
    if (!currentSeller) return false;
    const wallet = wallets[currentSeller.id] || wallets['seller_amaka'];
    if (!wallet) return false;

    // Rule: Account name must match verified ID
    const newAccount: PayoutAccount = {
      id: `payout_${Date.now()}`,
      bankCode,
      bankName,
      accountNumber,
      accountName,
      isVerified: true,
      coolingPeriodEndsAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24hr cooling period rule
      createdAt: new Date().toISOString(),
    };

    setWallets(prev => ({
      ...prev,
      [currentSeller.id]: {
        ...wallet,
        payoutAccounts: [...wallet.payoutAccounts, newAccount],
        activePayoutAccountId: newAccount.id,
      },
    }));

    notify(`Payout account ${bankName} (${accountNumber}) added! 24-hr cooling period activated for security.`, 'success');
    return true;
  };

  const toggleWalletFreeze = (sellerId: string, freeze: boolean, reason?: string) => {
    setWallets(prev => {
      const w = prev[sellerId];
      if (!w) return prev;
      return {
        ...prev,
        [sellerId]: {
          ...w,
          isFrozen: freeze,
          freezeReason: freeze ? (reason || 'Admin Security Review') : undefined,
        },
      };
    });
    notify(freeze ? `Wallet for ${sellerId} frozen by Admin.` : `Wallet for ${sellerId} unfrozen.`, 'info');
  };

  const toggleTwoFactor = () => {
    if (!currentUser) return;
    setSecurityProfiles(prev => {
      const p = prev[currentUser.id] || prev['user_tobi_buyer'];
      const nextVal = !p.twoFactorEnabled;
      notify(nextVal ? 'Two-Factor Authentication (2FA via SMS) enabled!' : 'Two-Factor Authentication disabled.', 'info');
      return {
        ...prev,
        [currentUser.id]: {
          ...p,
          twoFactorEnabled: nextVal,
        },
      };
    });
  };

  const revokeSession = (sessionId: string) => {
    if (!currentUser) return;
    setSecurityProfiles(prev => {
      const p = prev[currentUser.id] || prev['user_tobi_buyer'];
      return {
        ...prev,
        [currentUser.id]: {
          ...p,
          sessions: p.sessions.filter(s => s.id !== sessionId),
        },
      };
    });
    notify('Session logged out on other device.', 'info');
  };

  const buyerActiveOrdersCount = orders.filter(
    o => o.status !== 'completed' && o.status !== 'cancelled'
  ).length;

  // Phase 3: Report Problem Modal handlers
  const openReportProblemModal = (orderId: string) => {
    setActiveReportOrderId(orderId);
    setIsReportProblemModalOpen(true);
  };
  const closeReportProblemModal = () => {
    setIsReportProblemModalOpen(false);
    setActiveReportOrderId(null);
  };

  // Phase 3: Locked Chat Handlers
  const openChat = (
    conversationId?: string,
    targetInfo?: { orderId?: string; productId?: string; sellerId?: string }
  ) => {
    if (conversationId) {
      setActiveConversationId(conversationId);
      setActiveView('chat');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    if (targetInfo) {
      const existing = conversations.find(
        c => (targetInfo.orderId && c.orderId === targetInfo.orderId) ||
             (targetInfo.productId && c.productId === targetInfo.productId && c.sellerId === targetInfo.sellerId)
      );

      if (existing) {
        setActiveConversationId(existing.id);
      } else {
        const product = targetInfo.productId ? products.find(p => p.id === targetInfo.productId) : undefined;
        const seller = targetInfo.sellerId ? getSellerById(targetInfo.sellerId) : undefined;
        const newConvId = `conv_${Date.now()}`;
        const newConv: Conversation = {
          id: newConvId,
          orderId: targetInfo.orderId,
          productId: targetInfo.productId,
          productTitle: product?.title || (targetInfo.orderId ? `Order #${targetInfo.orderId}` : 'Campus Craft Inquiry'),
          productImage: product?.images[0],
          buyerId: currentUser?.id || 'user_tobi_buyer',
          buyerMaskedId: currentUser?.name ? `Buyer #${Math.floor(1000 + Math.random() * 9000)}` : 'Buyer #7821',
          sellerId: targetInfo.sellerId || product?.sellerId || 'seller_amaka',
          sellerShopName: seller?.shopName || product?.sellerShopName || 'Artisan Shop',
          lastMessage: 'Conversation opened',
          lastMessageAt: 'Just now',
          unreadBuyer: 0,
          unreadSeller: 0,
          isChatLocked: false,
          bypassViolationsCount: 0,
        };

        setConversations(prev => [newConv, ...prev]);
        setMessages(prev => ({
          ...prev,
          [newConvId]: [
            {
              id: `msg_${Date.now()}`,
              conversationId: newConvId,
              senderRole: 'system',
              senderMaskedName: 'Shop It Safety Bot',
              senderId: 'system',
              content: 'Locked Chat Active: Never pay or chat outside Shop It. Escrow protection is only guaranteed for in-app payments.',
              timestamp: 'Just now',
            },
          ],
        }));
        setActiveConversationId(newConvId);
      }
    }
    setActiveView('chat');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const sendMessage = (
    conversationId: string,
    content: string,
    customOrder?: any
  ): { success: boolean; isBlocked?: boolean; warning?: string } => {
    const conv = conversations.find(c => c.id === conversationId);
    if (!conv) return { success: false };

    if (conv.isChatLocked) {
      notify('This chat is locked by Shop It safety moderation due to repeated bypass attempts.', 'error');
      return { success: false, isBlocked: true, warning: 'Chat locked by moderation' };
    }

    const check = filterAntiBypass(content);
    let newViolationsCount = conv.bypassViolationsCount;

    if (check.isViolated) {
      newViolationsCount += 1;
      const isLockedNow = newViolationsCount >= 2;

      const newFlag: AntiBypassFlag = {
        id: `flag_${Date.now()}`,
        conversationId,
        senderId: currentUser?.id || 'user_anon',
        senderRole: currentUser?.role === 'seller' ? 'seller' : 'buyer',
        senderMaskedName: currentUser?.role === 'seller' ? (currentUser.sellerProfile?.shopName || 'Seller') : 'Buyer #7821',
        offendingText: content,
        maskedText: check.sanitizedText,
        detectedPatterns: check.detectedViolations,
        timestamp: 'Just now',
        status: isLockedNow ? 'chat_locked' : 'warning_issued',
      };

      setAntiBypassFlags(prev => [newFlag, ...prev]);

      if (isLockedNow) {
        setConversations(prev =>
          prev.map(c => c.id === conversationId ? { ...c, isChatLocked: true, bypassViolationsCount: newViolationsCount } : c)
        );
        notify('Chat locked! Repeated off-platform contact attempts detected. Sent to Admin Moderator.', 'error');
      } else {
        notify('Safety Warning: Off-platform contact details detected & masked! Never trade outside Shop It.', 'error');
      }
    }

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      conversationId,
      senderRole: currentUser?.role === 'seller' ? 'seller' : (currentUser?.role === 'admin' ? 'admin' : 'buyer'),
      senderMaskedName: currentUser?.role === 'seller'
        ? (currentUser.sellerProfile?.shopName || 'Seller')
        : (currentUser?.role === 'admin' ? 'Shop It Admin Support' : (conv.buyerMaskedId || 'Buyer #7821')),
      senderId: currentUser?.id || 'anon',
      content: check.isViolated ? check.sanitizedText : content,
      originalContent: check.isViolated ? content : undefined,
      isBlockedBypass: check.isViolated,
      blockedTokens: check.detectedViolations,
      timestamp: 'Just now',
      customOrderDetails: customOrder,
    };

    setMessages(prev => ({
      ...prev,
      [conversationId]: [...(prev[conversationId] || []), newMsg],
    }));

    setConversations(prev =>
      prev.map(c => {
        if (c.id === conversationId) {
          return {
            ...c,
            lastMessage: newMsg.content,
            lastMessageAt: 'Just now',
            bypassViolationsCount: newViolationsCount,
          };
        }
        return c;
      })
    );

    return {
      success: true,
      isBlocked: check.isViolated,
      warning: check.isViolated ? `Blocked patterns: ${check.detectedViolations.join(', ')}` : undefined,
    };
  };

  // Phase 3: Admin & Moderation Handlers
  const updateVerificationRequest = (id: string, status: 'approved' | 'rejected', notes?: string) => {
    setVerificationRequests(prev =>
      prev.map(req => {
        if (req.id === id) {
          return { ...req, status, notes: notes || req.notes };
        }
        return req;
      })
    );

    const targetReq = verificationRequests.find(r => r.id === id);
    if (targetReq && status === 'approved') {
      setSellers(prev =>
        prev.map(s => {
          if (s.id === targetReq.sellerId) {
            return {
              ...s,
              isVerifiedSeller: true,
              verificationStatus: 'approved',
              badges: Array.from(new Set([...s.badges, 'verified'])),
            };
          }
          return s;
        })
      );
      notify(`Seller "${targetReq.shopName}" approved! Verified badge granted.`, 'success');
    } else {
      notify(`Verification request marked as ${status}.`, 'info');
    }
  };

  const resolveDispute = (
    disputeId: string,
    resolution: 'refund_full' | 'release_seller' | 'partial',
    amount?: number,
    notes?: string
  ) => {
    const disp = disputes.find(d => d.id === disputeId);
    if (!disp) return;

    const ord = orders.find(o => o.id === disp.orderId);

    if (resolution === 'refund_full') {
      if (ord) updateOrderStatus(ord.id, 'cancelled');
      setWallets(prev => {
        const w = prev[disp.sellerId] || prev['seller_amaka'];
        if (!w) return prev;
        return {
          ...prev,
          [disp.sellerId]: {
            ...w,
            pendingBalance: Math.max(0, w.pendingBalance - disp.amountHeldInEscrow),
            transactions: [
              {
                id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
                type: 'refund',
                amount: disp.amountHeldInEscrow,
                fee: 0,
                balanceAfter: w.availableBalance,
                status: 'completed',
                description: `Dispute Resolved · Full Refund of ₦${disp.amountHeldInEscrow.toLocaleString()} to Buyer`,
                reference: disp.orderId,
                createdAt: 'Just now',
              },
              ...w.transactions,
            ],
          },
        };
      });

      setDisputes(prev =>
        prev.map(d => d.id === disputeId ? { ...d, status: 'resolved_refunded', resolutionNotes: notes } : d)
      );
      notify(`Dispute resolved: Full refund of ₦${disp.amountHeldInEscrow.toLocaleString()} returned to buyer.`, 'success');
    } else if (resolution === 'release_seller') {
      if (ord) updateOrderStatus(ord.id, 'completed');
      setWallets(prev => {
        const w = prev[disp.sellerId] || prev['seller_amaka'];
        if (!w) return prev;
        const newAvailable = w.availableBalance + disp.amountHeldInEscrow;
        return {
          ...prev,
          [disp.sellerId]: {
            ...w,
            availableBalance: newAvailable,
            pendingBalance: Math.max(0, w.pendingBalance - disp.amountHeldInEscrow),
            transactions: [
              {
                id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
                type: 'escrow_release',
                amount: disp.amountHeldInEscrow,
                fee: 0,
                balanceAfter: newAvailable,
                status: 'completed',
                description: `Dispute Resolved · Escrow released in seller favor`,
                reference: disp.orderId,
                createdAt: 'Just now',
              },
              ...w.transactions,
            ],
          },
        };
      });

      setDisputes(prev =>
        prev.map(d => d.id === disputeId ? { ...d, status: 'resolved_released', resolutionNotes: notes } : d)
      );
      notify(`Dispute resolved: ₦${disp.amountHeldInEscrow.toLocaleString()} released to seller wallet!`, 'success');
    } else if (resolution === 'partial') {
      const refundVal = amount || Math.round(disp.amountHeldInEscrow / 2);
      const sellerVal = disp.amountHeldInEscrow - refundVal;
      if (ord) updateOrderStatus(ord.id, 'completed');

      setWallets(prev => {
        const w = prev[disp.sellerId] || prev['seller_amaka'];
        if (!w) return prev;
        const newAvailable = w.availableBalance + sellerVal;
        return {
          ...prev,
          [disp.sellerId]: {
            ...w,
            availableBalance: newAvailable,
            pendingBalance: Math.max(0, w.pendingBalance - disp.amountHeldInEscrow),
            transactions: [
              {
                id: `TXN-${Math.floor(10000 + Math.random() * 90000)}`,
                type: 'escrow_release',
                amount: sellerVal,
                fee: 0,
                balanceAfter: newAvailable,
                status: 'completed',
                description: `Dispute Partial Resolution · ₦${sellerVal.toLocaleString()} released to seller`,
                reference: disp.orderId,
                createdAt: 'Just now',
              },
              ...w.transactions,
            ],
          },
        };
      });

      setDisputes(prev =>
        prev.map(d => d.id === disputeId ? { ...d, status: 'resolved_partial', refundAmount: refundVal, resolutionNotes: notes } : d)
      );
      notify(`Partial resolution: ₦${refundVal.toLocaleString()} refunded to buyer, ₦${sellerVal.toLocaleString()} released to seller.`, 'success');
    }
  };

  const updateFlagStatus = (flagId: string, action: 'warn' | 'lock_chat' | 'freeze_account' | 'dismiss') => {
    setAntiBypassFlags(prev =>
      prev.map(f => {
        if (f.id === flagId) {
          const newStatus = action === 'freeze_account'
            ? 'account_frozen'
            : (action === 'lock_chat' ? 'chat_locked' : 'reviewed');
          return { ...f, status: newStatus };
        }
        return f;
      })
    );

    const flag = antiBypassFlags.find(f => f.id === flagId);
    if (flag && action === 'lock_chat') {
      setConversations(prev =>
        prev.map(c => c.id === flag.conversationId ? { ...c, isChatLocked: true } : c)
      );
      notify(`Chat locked for flag #${flagId}.`, 'info');
    } else if (flag && action === 'freeze_account') {
      if (flag.senderRole === 'seller') {
        toggleWalletFreeze(flag.senderId, true, 'Anti-bypass repeated violation');
      }
      notify(`Account for sender ${flag.senderMaskedName} frozen for safety review.`, 'error');
    } else {
      notify(`Flag action: ${action} applied.`, 'info');
    }
  };

  const updateFeeSettings = (newSettings: Partial<FeeSettings>) => {
    setFeeSettings(prev => {
      const updated = { ...prev, ...newSettings };
      notify('Platform fee settings updated successfully!', 'success');
      return updated;
    });
  };

  const openCheckoutModal = () => setIsCheckoutModalOpen(true);
  const closeCheckoutModal = () => setIsCheckoutModalOpen(false);

  const toggleLowDataMode = () => {
    setLowDataMode(prev => {
      const next = !prev;
      notify(next ? 'Low-Data Mode ON (saving data on campus networks)' : 'Standard High-Res Mode ON', 'info');
      return next;
    });
  };

  const toggleLanguage = () => {
    setLanguage(prev => {
      const next = prev === 'en' ? 'pidgin' : 'en';
      notify(next === 'pidgin' ? 'Language set to Naija Pidgin' : 'Language set to English', 'info');
      return next;
    });
  };

  const openProduct = (id: string) => {
    setSelectedProductId(id);
    setActiveView('product_detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openSellerShop = (sellerId: string) => {
    setSelectedSellerId(sellerId);
    setActiveView('seller_shop');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedCampus('All Campuses');
    setPriceFilter('all');
    setSortBy('newest');
  };

  // Typo-tolerant and flexible search & filter logic
  const filteredProducts = products.filter(product => {
    const seller = getSellerById(product.sellerId);
    if (seller?.vacationMode) return false;

    if (selectedCategory !== 'all' && product.category !== selectedCategory) return false;
    if (selectedCampus !== 'All Campuses' && product.sellerCampus !== selectedCampus) return false;

    if (priceFilter === 'under2k' && product.displayPrice >= 2000) return false;
    if (priceFilter === '2k-5k' && (product.displayPrice < 2000 || product.displayPrice > 5000)) return false;
    if (priceFilter === '5k-10k' && (product.displayPrice < 5000 || product.displayPrice > 10000)) return false;
    if (priceFilter === 'above10k' && product.displayPrice <= 10000) return false;

    if (searchQuery.trim()) {
      const cleanQuery = searchQuery.toLowerCase().trim();
      const title = product.title.toLowerCase();
      const desc = product.description.toLowerCase();
      const shop = product.sellerShopName.toLowerCase();
      const campus = product.sellerCampus.toLowerCase();
      const cat = product.category.toLowerCase();

      if (title.includes(cleanQuery) || desc.includes(cleanQuery) || shop.includes(cleanQuery) || campus.includes(cleanQuery) || cat.includes(cleanQuery)) {
        return true;
      }

      const typoMap: Record<string, string[]> = {
        bead: ['bead', 'beads', 'waistbead', 'waistbeads', 'bracelet', 'charm'],
        scent: ['fragrance', 'perfume', 'mist', 'oil', 'scent', 'candle', 'diffuser', 'frangrance', 'fragrans'],
        bag: ['bag', 'bags', 'tote', 'crochet', 'clutch', 'pouch', 'knitted'],
        unilag: ['unilag', 'akoka', 'moremi'],
        ilorin: ['ilorin', 'unilorin'],
        ibadan: ['ui', 'ibadan'],
        nsukka: ['unn', 'nsukka'],
      };

      for (const [key, aliases] of Object.entries(typoMap)) {
        if (aliases.some(a => cleanQuery.includes(a) || a.includes(cleanQuery))) {
          if (title.includes(key) || desc.includes(key) || cat.includes(key)) {
            return true;
          }
        }
      }

      return false;
    }

    return true;
  }).sort((a, b) => {
    if (sortBy === 'newest') {
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
    if (sortBy === 'price_asc') {
      return a.displayPrice - b.displayPrice;
    }
    if (sortBy === 'price_desc') {
      return b.displayPrice - a.displayPrice;
    }
    if (sortBy === 'top_rated') {
      return b.rating - a.rating;
    }
    return 0;
  });

  return (
    <AppContext.Provider
      value={{
        currentUser,
        switchRole,
        login,
        logout,
        isAuthModalOpen,
        openAuthModal,
        closeAuthModal,
        authTab,
        setAuthTab,
        pendingAuthData,
        setPendingAuthData,
        verifyOtp,
        submitSellerRegistration,
        products,
        filteredProducts,
        addProduct,
        updateProduct,
        deleteProduct,
        toggleProductStock,
        sellers,
        getSellerById,
        currentSeller,
        toggleVacationMode,
        searchQuery,
        setSearchQuery,
        selectedCategory,
        setSelectedCategory,
        selectedCampus,
        setSelectedCampus,
        priceFilter,
        setPriceFilter,
        sortBy,
        setSortBy,
        resetFilters,
        activeView,
        setActiveView,
        selectedProductId,
        selectedSellerId,
        openProduct,
        openSellerShop,
        wishlist,
        toggleWishlist,
        cart,
        addToCart,
        removeFromCart,
        clearCart,
        cartCount,
        orders,
        placeOrder,
        updateOrderStatus,
        confirmItemReceived,
        cancelOrder,
        openDispute,
        submitOrderReview,
        buyerActiveOrdersCount,
        // Phase 3: Locked Chat
        conversations,
        messages,
        activeConversationId,
        setActiveConversationId,
        openChat,
        sendMessage,
        // Phase 3: Admin & Moderation
        adminSubRole,
        setAdminSubRole,
        verificationRequests,
        updateVerificationRequest,
        disputes,
        resolveDispute,
        antiBypassFlags,
        updateFlagStatus,
        feeSettings,
        updateFeeSettings,
        // Phase 3: Problem Modal
        isReportProblemModalOpen,
        activeReportOrderId,
        openReportProblemModal,
        closeReportProblemModal,
        wallets,
        currentWallet,
        requestWithdrawal,
        addPayoutAccount,
        toggleWalletFreeze,
        securityProfile: currentSecurityProfile,
        toggleTwoFactor,
        revokeSession,
        isCheckoutModalOpen,
        openCheckoutModal,
        closeCheckoutModal,
        appliedCoupon,
        applyCoupon,
        removeCoupon,
        lowDataMode,
        toggleLowDataMode,
        language,
        toggleLanguage,
        notifications,
        notify,
        dismissNotification,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
