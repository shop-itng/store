import React from 'react';
import { useApp } from '../context/AppContext';
import { CAMPUSES } from '../data/mockData';
import { ProductCategory, Campus } from '../types';
import { Search, MapPin, SlidersHorizontal, X, Sparkles } from 'lucide-react';

const CATEGORIES: { id: ProductCategory; label: string; icon: string }[] = [
  { id: 'all', label: 'All Crafts', icon: '✨' },
  { id: 'beads', label: 'Waist Beads & Jewelry', icon: '📿' },
  { id: 'fragrance', label: 'Fragrance & Scent Oils', icon: '🌿' },
  { id: 'bags', label: 'Crochet & Beaded Bags', icon: '🧶' },
  { id: 'fashion', label: 'Fashion & Wearables', icon: '👕' },
  { id: 'decor', label: 'Room Decor & Candles', icon: '🕯️' },
  { id: 'crafts', label: 'Art & Bespoke Crafts', icon: '🎨' },
];

export const TypoSearchBar: React.FC = () => {
  const {
    searchQuery,
    setSearchQuery,
    selectedCategory,
    setSelectedCategory,
    selectedCampus,
    setSelectedCampus,
    priceFilter,
    setPriceFilter,
    sortBy,
    setSortBy,
    resetFilters,
  } = useApp();

  const [showAdvancedFilters, setShowAdvancedFilters] = React.useState(false);

  const hasActiveFilters =
    searchQuery.trim() !== '' ||
    selectedCategory !== 'all' ||
    selectedCampus !== 'All Campuses' ||
    priceFilter !== 'all' ||
    sortBy !== 'newest';

  return (
    <div className="space-y-4">
      {/* Search Input and Campus Dropdown */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 sm:gap-3">
        <div className="relative sm:col-span-8">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search handmade waist beads, scent oils, crochet tote, UNILAG..."
            className="w-full h-11 pl-10 pr-10 rounded-xl bg-white border border-slate-200 text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-slate-900 focus:border-transparent transition-all shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Campus Location Filter */}
        <div className="relative sm:col-span-4 flex items-center gap-2">
          <div className="relative w-full">
            <MapPin className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 pointer-events-none" />
            <select
              value={selectedCampus}
              onChange={e => setSelectedCampus(e.target.value as Campus)}
              className="w-full h-11 pl-9 pr-8 rounded-xl bg-white border border-slate-200 text-xs sm:text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-slate-900 transition-all appearance-none cursor-pointer shadow-xs"
            >
              {CAMPUSES.map(campus => (
                <option key={campus} value={campus}>
                  {campus}
                </option>
              ))}
            </select>
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400 text-xs">
              ▼
            </div>
          </div>

          {/* Advanced filter toggle button */}
          <button
            onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
            className={`min-w-[44px] h-11 px-3 rounded-xl border flex items-center justify-center gap-1.5 text-xs font-medium transition-colors shrink-0 ${
              showAdvancedFilters || priceFilter !== 'all' || sortBy !== 'newest'
                ? 'bg-slate-900 text-white border-slate-900'
                : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
            }`}
            title="Sort and Price Filters"
          >
            <SlidersHorizontal className="w-4 h-4" />
            <span className="hidden sm:inline">Filter</span>
          </button>
        </div>
      </div>

      {/* Category Horizontal Filter Bar (Interactive Buttons - Zero-Pill discipline compliant) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none text-xs">
        {CATEGORIES.map(cat => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`h-9 px-3.5 rounded-xl whitespace-nowrap shrink-0 font-semibold transition-all flex items-center gap-1.5 active:scale-[0.98] ${
                isActive
                  ? 'bg-[#0c0d10] text-white border border-[#0c0d10] shadow-xs'
                  : 'bg-white text-stone-700 border border-stone-200 hover:text-black hover:border-stone-300'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
              {isActive && <span className="w-1.5 h-1.5 rounded-full bg-[#f95700] ml-0.5" />}
            </button>
          );
        })}
      </div>

      {/* Collapsible Advanced Filters: Price range & Sort */}
      {showAdvancedFilters && (
        <div className="p-4 bg-white rounded-xl border border-slate-200 space-y-4 transition-all">
          <div className="flex flex-wrap items-center justify-between gap-4">
            {/* Price ranges */}
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                Price Range
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'all', label: 'All Prices' },
                  { id: 'under2k', label: 'Under ₦2,000' },
                  { id: '2k-5k', label: '₦2,000 – ₦5,000' },
                  { id: '5k-10k', label: '₦5,000 – ₦10,000' },
                  { id: 'above10k', label: 'Above ₦10,000' },
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => setPriceFilter(p.id as any)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      priceFilter === p.id
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort by */}
            <div>
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-2">
                Sort By
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { id: 'newest', label: 'Newest Arrivals' },
                  { id: 'price_asc', label: 'Price: Low to High' },
                  { id: 'price_desc', label: 'Price: High to Low' },
                  { id: 'top_rated', label: 'Top Rated' },
                ].map(s => (
                  <button
                    key={s.id}
                    onClick={() => setSortBy(s.id as any)}
                    className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors ${
                      sortBy === s.id
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Active filters pill & reset */}
      {hasActiveFilters && (
        <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
          <div className="flex items-center gap-2">
            <span>Filtering active results</span>
            {selectedCampus !== 'All Campuses' && (
              <span className="text-slate-800 font-medium">· {selectedCampus}</span>
            )}
            {selectedCategory !== 'all' && (
              <span className="text-slate-800 font-medium">
                · {CATEGORIES.find(c => c.id === selectedCategory)?.label}
              </span>
            )}
          </div>
          <button
            onClick={resetFilters}
            className="text-xs text-emerald-700 hover:text-emerald-900 font-medium underline"
          >
            Reset all
          </button>
        </div>
      )}
    </div>
  );
};
