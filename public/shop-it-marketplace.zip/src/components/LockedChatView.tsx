import React, { useState, useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShieldAlert,
  Send,
  Lock,
  ArrowLeft,
  Sparkles,
  ShoppingBag,
  AlertCircle,
  CheckCircle,
  MessageSquare,
  Package,
  Layers,
  ChevronRight,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { filterAntiBypass } from '../utils/antiBypass';
import { formatNaira } from '../utils/pricing';

export const LockedChatView: React.FC = () => {
  const {
    currentUser,
    conversations,
    messages,
    activeConversationId,
    setActiveConversationId,
    sendMessage,
    setActiveView,
    openProduct,
    openCheckoutModal,
    cart,
    addToCart,
    products,
  } = useApp();

  const [inputContent, setInputContent] = useState('');
  const [showCustomOrderModal, setShowCustomOrderModal] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customColor, setCustomColor] = useState('Pastel Candy Beads');
  const [customNotes, setCustomNotes] = useState('');
  const [liveWarning, setLiveWarning] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeConv = conversations.find(c => c.id === activeConversationId) || conversations[0];
  const activeMessages = activeConv ? messages[activeConv.id] || [] : [];

  const matchedProduct = activeConv?.productId
    ? products.find(p => p.id === activeConv.productId)
    : undefined;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeMessages]);

  // Real-time live scanning while typing
  const handleInputChange = (text: string) => {
    setInputContent(text);
    const check = filterAntiBypass(text);
    if (check.isViolated) {
      setLiveWarning(`Notice: Off-platform contact info (${check.detectedViolations.join(', ')}) will be blocked on send.`);
    } else {
      setLiveWarning(null);
    }
  };

  const handleSend = (textToSend?: string, customOrderData?: any) => {
    const content = textToSend || inputContent;
    if (!content.trim() && !customOrderData) return;
    if (!activeConv) return;

    sendMessage(activeConv.id, content, customOrderData);
    setInputContent('');
    setLiveWarning(null);
  };

  const handleCustomOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() && !customNotes.trim()) return;

    const summaryText = `Custom Order Request: Name "${customName || 'N/A'}", Color: ${customColor}. Notes: ${customNotes || 'Standard'}`;
    handleSend(summaryText, {
      customName,
      color: customColor,
      notes: customNotes,
    });
    setShowCustomOrderModal(false);
    setCustomName('');
    setCustomNotes('');
  };

  // Preset quick replies
  const quickReplies = [
    'Is this item currently available?',
    'Can you deliver to my campus hostel?',
    'Ready to pay into Escrow now',
    'I have received the package, thanks!',
    'Request Custom Order',
  ];

  const handleQuickReplyClick = (reply: string) => {
    if (reply === 'Request Custom Order') {
      setShowCustomOrderModal(true);
    } else {
      handleSend(reply);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6">
      {/* Top Header & Breadcrumb */}
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setActiveView('catalog')}
          className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-stone-700 hover:text-black transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Marketplace</span>
        </button>
        <div className="flex items-center gap-1.5 px-3 py-1 bg-[#ecf5f0] border border-[#bce0cc] rounded-xl text-xs font-semibold text-[#123524]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#123524]" />
          <span>Shop It Escrow Protected</span>
        </div>
      </div>

      {/* Main Chat Container */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden grid grid-cols-1 md:grid-cols-12 min-h-[620px] max-h-[820px]">
        {/* Left Sidebar: Conversations List (Hidden on small mobile when chatting) */}
        <div className="hidden md:flex md:col-span-4 border-r border-stone-200 flex-col bg-stone-50/40">
          <div className="p-4 border-b border-stone-200 bg-white">
            <h2 className="text-base font-bold font-heading text-stone-900 flex items-center gap-2">
              <MessageSquare className="w-4 h-4 text-[#f95700]" />
              <span>Messages & Enquiries</span>
            </h2>
            <p className="text-[11px] text-stone-500 mt-0.5">
              Secure in-app communication
            </p>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-stone-100">
            {conversations.map(conv => {
              const isSelected = conv.id === activeConv?.id;
              return (
                <div
                  key={conv.id}
                  onClick={() => setActiveConversationId(conv.id)}
                  className={`p-3.5 cursor-pointer transition-colors flex items-start gap-3 ${
                    isSelected ? 'bg-white border-l-4 border-l-[#f95700] shadow-xs' : 'hover:bg-stone-100/60'
                  }`}
                >
                  <div className="w-10 h-10 rounded-xl bg-stone-200 overflow-hidden shrink-0 border border-stone-200">
                    {conv.productImage ? (
                      <img src={conv.productImage} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-[#123524] text-white flex items-center justify-center font-bold text-xs">
                        {conv.sellerShopName[0]}
                      </div>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-stone-900 truncate">
                        {currentUser?.role === 'seller' ? conv.buyerMaskedId : conv.sellerShopName}
                      </h4>
                      <span className="text-[10px] text-stone-400 shrink-0">{conv.lastMessageAt}</span>
                    </div>

                    <p className="text-[11px] text-stone-600 truncate mt-0.5">
                      {conv.lastMessage}
                    </p>

                    {conv.productTitle && (
                      <div className="mt-1 flex items-center gap-1 text-[10px] text-stone-500 truncate">
                        <Package className="w-3 h-3 text-[#f95700] shrink-0" />
                        <span className="truncate">{conv.productTitle}</span>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Active Chat Window */}
        <div className="col-span-1 md:col-span-8 flex flex-col h-full bg-white">
          {activeConv ? (
            <>
              {/* Active Conversation Top Bar */}
              <div className="p-3.5 sm:p-4 border-b border-stone-200 bg-[#0c0d10] text-white flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-stone-800 border border-stone-700 overflow-hidden shrink-0">
                    {activeConv.productImage ? (
                      <img src={activeConv.productImage} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-[#123524] text-white flex items-center justify-center font-bold text-sm">
                        {activeConv.sellerShopName[0]}
                      </div>
                    )}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-xs sm:text-sm font-bold font-heading text-white truncate">
                        {currentUser?.role === 'seller' ? activeConv.buyerMaskedId : activeConv.sellerShopName}
                      </h3>
                      {currentUser?.role === 'seller' && (
                        <span className="px-2 py-0.5 bg-stone-800 border border-stone-700 text-[10px] text-stone-300 rounded-md">
                          Identity Hidden
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-stone-400 truncate">
                      {activeConv.productTitle || (activeConv.orderId ? `Order #${activeConv.orderId}` : 'Campus Craft')}
                    </p>
                  </div>
                </div>

                {matchedProduct && (
                  <button
                    onClick={() => openProduct(matchedProduct.id)}
                    className="hidden sm:flex items-center gap-1 px-3 py-1.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-white text-xs font-semibold border border-stone-700 transition-colors"
                  >
                    <span>View Craft</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              {/* Safety Anti-Bypass Banner */}
              <div className="px-3.5 py-2 bg-[#fff2ea] border-b border-[#fed7aa] flex items-center gap-2 text-xs text-stone-800">
                <ShieldAlert className="w-4 h-4 text-[#f95700] shrink-0" />
                <span className="leading-snug text-[11px] sm:text-xs">
                  <strong className="text-stone-900">Anti-Bypass Safety Notice:</strong> Never pay or chat outside Shop It. Phone numbers, bank accounts, and off-platform links are automatically blocked to protect your escrow.
                </span>
              </div>

              {/* Chat Messages Stream */}
              <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 bg-stone-50/30">
                {activeMessages.map(msg => {
                  const isMe =
                    (currentUser?.role === 'seller' && msg.senderRole === 'seller') ||
                    (currentUser?.role === 'buyer' && msg.senderRole === 'buyer') ||
                    (currentUser?.role === 'admin' && msg.senderRole === 'admin');

                  const isSystem = msg.senderRole === 'system';

                  if (isSystem) {
                    return (
                      <div key={msg.id} className="flex justify-center my-2">
                        <div className="px-3 py-1.5 rounded-xl bg-stone-200/80 border border-stone-300 text-[11px] text-stone-700 font-medium text-center max-w-md flex items-center gap-1.5">
                          <Lock className="w-3.5 h-3.5 text-stone-600 shrink-0" />
                          <span>{msg.content}</span>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                    >
                      <span className="text-[10px] text-stone-400 mb-0.5 px-1 font-medium">
                        {msg.senderMaskedName} · {msg.timestamp}
                      </span>

                      <div
                        className={`max-w-[85%] sm:max-w-[70%] p-3 rounded-2xl text-xs sm:text-sm leading-relaxed shadow-xs ${
                          isMe
                            ? 'bg-[#0c0d10] text-white rounded-tr-none'
                            : 'bg-white text-stone-900 border border-stone-200 rounded-tl-none'
                        }`}
                      >
                        {msg.isBlockedBypass ? (
                          <div className="space-y-1">
                            <p className="font-mono text-xs">{msg.content}</p>
                            <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-red-950/30 border border-red-500/30 text-[10px] text-red-300">
                              <AlertCircle className="w-3 h-3" />
                              <span>Off-platform contact blocked by safety filter</span>
                            </div>
                          </div>
                        ) : (
                          <p className="whitespace-pre-wrap">{msg.content}</p>
                        )}

                        {/* Custom order attachment card */}
                        {msg.customOrderDetails && (
                          <div className={`mt-2.5 p-2.5 rounded-xl border text-xs ${
                            isMe ? 'bg-stone-900 border-stone-800' : 'bg-stone-50 border-stone-200'
                          }`}>
                            <div className="flex items-center gap-1.5 font-bold text-[#f95700] mb-1">
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Structured Custom Order Request</span>
                            </div>
                            {msg.customOrderDetails.customName && (
                              <p className="text-[11px]">
                                <strong>Bead Name / Lettering:</strong> "{msg.customOrderDetails.customName}"
                              </p>
                            )}
                            {msg.customOrderDetails.color && (
                              <p className="text-[11px]">
                                <strong>Color Palette:</strong> {msg.customOrderDetails.color}
                              </p>
                            )}
                            {msg.customOrderDetails.notes && (
                              <p className="text-[11px] text-stone-400">
                                <strong>Notes:</strong> {msg.customOrderDetails.notes}
                              </p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              {/* Real-time live warning banner when typing blocked terms */}
              {liveWarning && (
                <div className="px-3 py-1.5 bg-red-50 border-t border-red-200 text-red-700 text-[11px] flex items-center gap-1.5">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{liveWarning}</span>
                </div>
              )}

              {/* Quick Reply Action Buttons */}
              <div className="p-2 bg-stone-100/60 border-t border-stone-200 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                <span className="text-[11px] font-semibold text-stone-500 shrink-0 pl-1">
                  Quick Reply:
                </span>
                {quickReplies.map((qr, i) => (
                  <button
                    key={i}
                    onClick={() => handleQuickReplyClick(qr)}
                    className="px-2.5 py-1 bg-white hover:bg-stone-200/70 border border-stone-200 rounded-lg text-xs font-semibold text-stone-800 shrink-0 transition-colors active:scale-95 flex items-center gap-1"
                  >
                    {qr === 'Request Custom Order' && <Sparkles className="w-3 h-3 text-[#f95700]" />}
                    <span>{qr}</span>
                  </button>
                ))}
              </div>

              {/* Message Input Box */}
              <div className="p-3 bg-white border-t border-stone-200">
                <form
                  onSubmit={e => {
                    e.preventDefault();
                    handleSend();
                  }}
                  className="flex items-center gap-2"
                >
                  <input
                    type="text"
                    value={inputContent}
                    onChange={e => handleInputChange(e.target.value)}
                    placeholder="Type a message (contact details will be blocked)..."
                    className="flex-1 px-3.5 py-2.5 rounded-xl border border-stone-200 focus:outline-none focus:border-[#f95700] focus:ring-1 focus:ring-[#f95700] text-xs sm:text-sm bg-stone-50/60"
                  />
                  <button
                    type="submit"
                    disabled={!inputContent.trim()}
                    className="p-2.5 sm:px-4 sm:py-2.5 rounded-xl bg-[#f95700] hover:bg-[#e04b00] text-white font-semibold text-xs sm:text-sm transition-all shadow-xs active:scale-[0.98] disabled:opacity-40 flex items-center gap-1.5"
                  >
                    <Send className="w-4 h-4" />
                    <span className="hidden sm:inline">Send</span>
                  </button>
                </form>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-stone-500">
              <MessageSquare className="w-12 h-12 text-stone-300 mb-2" />
              <p className="text-sm font-semibold">Select a conversation to start chatting</p>
            </div>
          )}
        </div>
      </div>

      {/* Structured Custom Order Modal */}
      {showCustomOrderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/75 backdrop-blur-xs">
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-stone-200 overflow-hidden">
            <div className="p-4 bg-[#0c0d10] text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#f95700]" />
                <h3 className="text-sm sm:text-base font-bold font-heading">
                  Custom Order Form
                </h3>
              </div>
              <button
                onClick={() => setShowCustomOrderModal(false)}
                className="text-stone-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCustomOrderSubmit} className="p-4 space-y-3 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-stone-900 mb-1">
                  Name / Initials to Bead or Engrave
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={customName}
                  onChange={e => setCustomName(e.target.value)}
                  placeholder="e.g. TOBI or AMINA"
                  className="w-full p-2.5 rounded-xl border border-stone-200 text-xs sm:text-sm focus:border-[#f95700] focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-900 mb-1">
                  Preferred Color Scheme
                </label>
                <select
                  value={customColor}
                  onChange={e => setCustomColor(e.target.value)}
                  className="w-full p-2.5 rounded-xl border border-stone-200 text-xs sm:text-sm focus:border-[#f95700] focus:outline-none"
                >
                  <option value="Pastel Candy Pink & Gold">Pastel Candy Pink & Gold</option>
                  <option value="Earthy Terracotta & Olive">Earthy Terracotta & Olive</option>
                  <option value="Crystal Iridescent & Pearls">Crystal Iridescent & Pearls</option>
                  <option value="Black & Gold Luxury">Black & Gold Luxury</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-stone-900 mb-1">
                  Additional Notes / Measurements
                </label>
                <textarea
                  rows={2}
                  value={customNotes}
                  onChange={e => setCustomNotes(e.target.value)}
                  placeholder="e.g. 28-inch waist length or extra charm on the clasp"
                  className="w-full p-2.5 rounded-xl border border-stone-200 text-xs sm:text-sm resize-none focus:border-[#f95700] focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCustomOrderModal(false)}
                  className="px-3.5 py-2 rounded-xl border border-stone-300 font-semibold text-xs text-stone-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#f95700] hover:bg-[#e04b00] text-white font-semibold text-xs shadow-xs active:scale-95"
                >
                  Send Custom Request
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
