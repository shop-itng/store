import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldCheck, Lock, Heart, MapPin } from 'lucide-react';

export const Footer: React.FC = () => {
  const { setSelectedCampus, setSelectedCategory, setActiveView } = useApp();

  return (
    <footer className="bg-white border-t border-slate-200 mt-16 pt-12 pb-24 md:pb-12 text-xs text-slate-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand & NDPA notice */}
          <div className="space-y-3">
            <span className="text-lg font-black text-slate-900 tracking-tight block">
              Shop It Nigeria
            </span>
            <p className="text-xs text-slate-600 leading-relaxed">
              Empowering student and teen artisans across Nigerian universities to sell handmade beads,
              perfumes, bags, and decor with escrow protection.
            </p>
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-800 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>NDPA Compliant · Anti-Bypass Guarded</span>
            </div>
          </div>

          {/* Col 2: Top Campus Hubs */}
          <div className="space-y-3">
            <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
              Top Campus Hubs
            </span>
            <ul className="space-y-2 text-slate-600">
              {['UNILAG (Akoka)', 'UI (Ibadan)', 'UNILORIN', 'UNN (Nsukka)', 'OAU (Ile-Ife)'].map(
                campus => (
                  <li key={campus}>
                    <button
                      onClick={() => {
                        setSelectedCampus(campus as any);
                        setActiveView('catalog');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="hover:text-slate-900 transition-colors"
                    >
                      {campus} Hub
                    </button>
                  </li>
                )
              )}
            </ul>
          </div>

          {/* Col 3: Handmade Categories */}
          <div className="space-y-3">
            <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
              Handmade Crafts
            </span>
            <ul className="space-y-2 text-slate-600">
              <li>
                <button
                  onClick={() => {
                    setSelectedCategory('beads');
                    setActiveView('catalog');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-slate-900"
                >
                  Layered Glass Waist Beads
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategory('fragrance');
                    setActiveView('catalog');
                  }}
                  className="hover:text-slate-900"
                >
                  Pure Roll-On Perfumes & Mists
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategory('bags');
                    setActiveView('catalog');
                  }}
                  className="hover:text-slate-900"
                >
                  Crochet Tote Bags & Clutches
                </button>
              </li>
              <li>
                <button
                  onClick={() => {
                    setSelectedCategory('decor');
                    setActiveView('catalog');
                  }}
                  className="hover:text-slate-900"
                >
                  Wood-Wick Soy Scented Candles
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Trust & Safety */}
          <div className="space-y-3">
            <span className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
              Student Trust & Safety
            </span>
            <p className="text-[11px] text-slate-500 leading-normal">
              Never pay off-platform via WhatsApp or direct transfer. All payments are held in escrow
              until the buyer confirms delivery.
            </p>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] space-y-1">
              <div className="font-semibold text-slate-800">Teen Artisan Protection</div>
              <p className="text-slate-500">
                Sellers under 18 operate with verified parent/guardian banking consent.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom copyright and project download */}
        <div className="pt-6 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <div>© {new Date().getFullYear()} Shop It Marketplace Ltd. Made for Nigerian Students.</div>
          <div className="flex items-center gap-4">
            <a
              href="/shop-it-marketplace.zip"
              download="shop-it-marketplace.zip"
              className="text-[#f95700] hover:text-[#e04b00] font-bold underline flex items-center gap-1"
            >
              Download Full Project Code (.zip)
            </a>
            <span>·</span>
            <span>Currency: Nigerian Naira (₦)</span>
            <span>·</span>
            <span>Escrow Protected</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
