import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatNaira } from '../utils/pricing';
import { CAMPUSES } from '../data/mockData';
import { Campus, OrderItem } from '../types';
import {
  X,
  CreditCard,
  Building2,
  PhoneCall,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Tag,
  ArrowRight,
  Truck,
  MapPin,
  Clock,
  Sparkles,
  AlertCircle,
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutModalOpen,
    closeCheckoutModal,
    cart,
    currentUser,
    placeOrder,
    setActiveView,
    appliedCoupon,
    applyCoupon,
    removeCoupon,
    notify,
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'paystack_card' | 'paystack_transfer' | 'ussd'>('paystack_card');
  const [selectedCampus, setSelectedCampus] = useState<Campus>(
    (currentUser?.savedDeliveryArea as Campus) || 'UNILAG (Akoka)'
  );
  const [deliveryAreaNote, setDeliveryAreaNote] = useState('New Hall Quad Hub / Moremi');
  const [hostelRoomNote, setHostelRoomNote] = useState('Room 312 (Couriers only)');
  const [couponInput, setCouponInput] = useState('');

  // Payment form states
  const [cardNumber, setCardNumber] = useState('5399 •••• •••• 4120');
  const [cardExpiry, setCardExpiry] = useState('08/28');
  const [cardCvv, setCardCvv] = useState('912');
  const [cardPin, setCardPin] = useState('1234');
  const [isProcessing, setIsProcessing] = useState(false);
  const [transferConfirmed, setTransferConfirmed] = useState(false);

  if (!isCheckoutModalOpen || cart.length === 0) return null;

  // Group delivery fees by seller (1 combined fee per seller)
  const sellersInCart = Array.from(new Set(cart.map(i => i.product.sellerShopName)));
  const subtotalItems = cart.reduce((sum, item) => sum + item.product.sellerPrice * item.quantity, 0);
  const totalServiceFees = cart.reduce((sum, item) => sum + item.product.serviceFee * item.quantity, 0);

  const deliveryTotal = sellersInCart.reduce((sum, sellerName) => {
    const sellerItems = cart.filter(i => i.product.sellerShopName === sellerName);
    const maxFee = Math.max(
      ...sellerItems.map(i =>
        i.deliveryMethod === 'pickup'
          ? i.product.delivery.pickupFee
          : i.product.delivery.localDeliveryFee
      )
    );
    return sum + (maxFee > 0 ? maxFee : 200);
  }, 0);

  const discountAmount = appliedCoupon ? appliedCoupon.discountAmount : 0;
  const grandTotal = Math.max(0, subtotalItems + totalServiceFees + deliveryTotal - discountAmount);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    applyCoupon(couponInput, subtotalItems + totalServiceFees);
  };

  const handleCompletePayment = () => {
    setIsProcessing(true);

    // Simulate Paystack webhook / 3DS escrow verification
    setTimeout(() => {
      setIsProcessing(false);

      const orderItems: OrderItem[] = cart.map(item => ({
        productId: item.product.id,
        title: item.product.title,
        image: item.product.images[0] || '',
        sellerId: item.product.sellerId,
        sellerShopName: item.product.sellerShopName,
        sellerCampus: item.product.sellerCampus,
        quantity: item.quantity,
        sellerPrice: item.product.sellerPrice,
        serviceFee: item.product.serviceFee,
        displayPrice: item.product.displayPrice,
        selectedColor: item.selectedColor,
        selectedSize: item.selectedSize,
        customNameText: item.customNameText,
        deliveryMethod: item.deliveryMethod,
        deliveryFee: item.deliveryMethod === 'pickup' ? item.product.delivery.pickupFee : item.product.delivery.localDeliveryFee,
      }));

      const newOrder = placeOrder({
        buyerId: currentUser?.id || 'guest_buyer',
        buyerMaskedId: `Buyer #${Math.floor(1000 + Math.random() * 9000)}`,
        buyerName: currentUser?.name || 'Student Shopper',
        deliveryArea: `${selectedCampus} · ${deliveryAreaNote}`,
        pickupPoint: deliveryAreaNote,
        items: orderItems,
        itemsSubtotal: subtotalItems,
        serviceFeeTotal: totalServiceFees,
        deliveryTotal,
        discountTotal: discountAmount,
        couponCode: appliedCoupon?.code,
        grandTotal,
        status: 'paid',
        paymentMethod: paymentMethod === 'ussd' ? 'paystack_transfer' : paymentMethod,
        paymentReference: `PSTK_ESCROW_${Math.floor(100000 + Math.random() * 900000)}`,
      });

      closeCheckoutModal();
      setActiveView('orders');
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-xl w-full p-5 sm:p-8 space-y-6 shadow-2xl relative my-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-black text-xs">
              P
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-base font-extrabold text-slate-900">Paystack Escrow Checkout</h2>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                  Secured
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Payment is held in escrow until you confirm delivery.
              </p>
            </div>
          </div>

          <button
            onClick={closeCheckoutModal}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 min-h-[38px] min-w-[38px] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Delivery / Campus Hub Selection */}
        <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200/90 text-xs">
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-900 flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-emerald-600" />
              <span>Campus Delivery Destination</span>
            </span>
            <span className="text-slate-500 text-[11px]">Handled in-app</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div>
              <label className="text-[11px] font-semibold text-slate-600 block mb-1">Campus</label>
              <select
                value={selectedCampus}
                onChange={e => setSelectedCampus(e.target.value as Campus)}
                className="w-full h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-900"
              >
                {CAMPUSES.filter(c => c !== 'All Campuses').map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                Pickup Point / Quad
              </label>
              <input
                type="text"
                value={deliveryAreaNote}
                onChange={e => setDeliveryAreaNote(e.target.value)}
                placeholder="e.g. New Hall Quad or SUB Gate"
                className="w-full h-9 px-2.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-900"
              />
            </div>
          </div>

          {/* Privacy Notice on exact delivery address */}
          <div className="p-2 bg-white rounded-lg border border-slate-200 text-[11px] text-slate-500">
            <strong>Anti-Bypass Privacy: </strong>
            The seller only sees your <strong>Buyer #ID</strong> and campus area (
            {selectedCampus}). Your private phone number and room number are never exposed to the seller.
          </div>
        </div>

        {/* Promo Code Input */}
        <div className="flex items-center gap-2">
          {appliedCoupon ? (
            <div className="flex-1 flex items-center justify-between p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900">
              <div className="flex items-center gap-1.5">
                <Tag className="w-3.5 h-3.5 text-emerald-600" />
                <span>
                  <strong>{appliedCoupon.code}</strong> applied ({formatNaira(appliedCoupon.discountAmount)} off)
                </span>
              </div>
              <button
                type="button"
                onClick={removeCoupon}
                className="text-xs text-rose-600 hover:underline font-semibold"
              >
                Remove
              </button>
            </div>
          ) : (
            <form onSubmit={handleApplyCoupon} className="flex-1 flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={couponInput}
                  onChange={e => setCouponInput(e.target.value)}
                  placeholder="Promo Code (try: CAMPUSLOVE or FIRSTCRAFT)"
                  className="w-full h-10 pl-9 pr-3 rounded-xl border border-slate-200 text-xs text-slate-900 uppercase"
                />
              </div>
              <button
                type="submit"
                className="px-3.5 h-10 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors shrink-0"
              >
                Apply
              </button>
            </form>
          )}
        </div>

        {/* Payment Gateway Options (Paystack or Flutterwave) */}
        <div className="space-y-3">
          <label className="text-xs font-bold text-slate-900 block">
            Select Payment Method
          </label>

          <div className="grid grid-cols-3 gap-2">
            <button
              type="button"
              onClick={() => setPaymentMethod('paystack_card')}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                paymentMethod === 'paystack_card'
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span className="text-xs font-bold">Debit Card</span>
              <span className="text-[10px] opacity-75">Mastercard/Verve</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('paystack_transfer')}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                paymentMethod === 'paystack_transfer'
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Building2 className="w-4 h-4" />
              <span className="text-xs font-bold">Bank Transfer</span>
              <span className="text-[10px] opacity-75">Titan / Wema Bank</span>
            </button>

            <button
              type="button"
              onClick={() => setPaymentMethod('ussd')}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition-all ${
                paymentMethod === 'ussd'
                  ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                  : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
              }`}
            >
              <PhoneCall className="w-4 h-4" />
              <span className="text-xs font-bold">USSD</span>
              <span className="text-[10px] opacity-75">*737# / *919#</span>
            </button>
          </div>

          {/* Card Form Simulation */}
          {paymentMethod === 'paystack_card' && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                  Card Number (Never stored on server)
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={e => setCardNumber(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-xs font-mono-numbers text-slate-900"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">
                    VERVE / VISA
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1">
                    Expiry (MM/YY)
                  </label>
                  <input
                    type="text"
                    value={cardExpiry}
                    onChange={e => setCardExpiry(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-xs font-mono-numbers text-slate-900 text-center"
                  />
                </div>
                <div>
                  <label className="text-[11px] font-semibold text-slate-600 block mb-1">CVV</label>
                  <input
                    type="password"
                    maxLength={3}
                    value={cardCvv}
                    onChange={e => setCardCvv(e.target.value)}
                    className="w-full h-10 px-3 rounded-lg border border-slate-200 bg-white text-xs font-mono-numbers text-slate-900 text-center"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Simulated Virtual Bank Transfer */}
          {paymentMethod === 'paystack_transfer' && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3 text-xs">
              <div className="flex items-center justify-between text-slate-700">
                <span>Transfer exact amount to:</span>
                <span className="font-extrabold text-slate-900 font-mono-numbers text-sm">
                  {formatNaira(grandTotal)}
                </span>
              </div>

              <div className="bg-white p-3.5 rounded-xl border border-slate-200 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Bank Name</span>
                  <strong className="text-slate-900">Wema Bank / Paystack Titan</strong>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Account Number</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-bold text-base font-mono-numbers text-emerald-800">
                      9948 2103 81
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard?.writeText?.('9948210381');
                        notify('Account number copied!', 'success');
                      }}
                      className="text-[10px] bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded font-semibold text-slate-700"
                    >
                      Copy
                    </button>
                  </div>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Account Name</span>
                  <span className="font-medium text-slate-800">Shop It Escrow - Student Order</span>
                </div>
              </div>

              <p className="text-[11px] text-slate-500">
                Use your bank app or Opay to transfer. Your order will be confirmed in under 60 seconds.
              </p>
            </div>
          )}

          {/* USSD Simulation */}
          {paymentMethod === 'ussd' && (
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
              <span className="font-bold text-slate-800 block">Dial USSD Code on your phone:</span>
              <div className="bg-white p-3 rounded-xl border border-slate-200 font-mono text-center text-sm font-bold text-slate-900 tracking-wider">
                *737*2*{grandTotal}*9948210381#
              </div>
              <p className="text-[11px] text-slate-500 text-center">
                Follow phone prompts to authorize via GTBank, Zenith or UBA.
              </p>
            </div>
          )}
        </div>

        {/* Final Price Breakdown (Prompt Rule: Item price + fee + delivery - coupon = Total) */}
        <div className="pt-3 border-t border-slate-200 space-y-1.5 text-xs text-slate-600">
          <div className="flex justify-between">
            <span>Items Subtotal</span>
            <span className="font-mono-numbers">{formatNaira(subtotalItems)}</span>
          </div>
          <div className="flex justify-between text-emerald-800">
            <span>Shop It Buyer Protection Fee</span>
            <span className="font-mono-numbers">+{formatNaira(totalServiceFees)}</span>
          </div>
          <div className="flex justify-between">
            <span>Campus Delivery / Pickup</span>
            <span className="font-mono-numbers">+{formatNaira(deliveryTotal)}</span>
          </div>
          {discountAmount > 0 && (
            <div className="flex justify-between text-rose-700 font-semibold">
              <span>Coupon Discount ({appliedCoupon?.code})</span>
              <span className="font-mono-numbers">-{formatNaira(discountAmount)}</span>
            </div>
          )}

          <div className="pt-2 border-t border-slate-200 flex justify-between items-baseline text-slate-900">
            <span className="text-sm font-bold">Total Amount to Pay</span>
            <span className="text-xl font-black font-mono-numbers text-slate-900">
              {formatNaira(grandTotal)}
            </span>
          </div>
        </div>

        {/* Pay Button */}
        <button
          onClick={handleCompletePayment}
          disabled={isProcessing}
          className="w-full h-12 bg-[#f95700] hover:bg-[#e04b00] disabled:bg-stone-400 text-white font-bold text-sm rounded-xl transition-all shadow-md shadow-[#f95700]/20 flex items-center justify-center gap-2 active:scale-[0.99]"
        >
          {isProcessing ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              <span>Verifying with Paystack Escrow...</span>
            </div>
          ) : (
            <>
              <Lock className="w-4 h-4 text-white" />
              <span>Authorize & Pay {formatNaira(grandTotal)}</span>
            </>
          )}
        </button>

        {/* Escrow Guarantee Footer Note */}
        <div className="text-[11px] text-slate-400 text-center flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Payment held safely in escrow until you inspect your handmade craft.</span>
        </div>
      </div>
    </div>
  );
};
