import React from 'react';
import { useApp } from '../context/AppContext';
import { ShoppingBag, Heart, User, Store, ShieldCheck, Zap, MessageSquare, Shield } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentUser,
    openAuthModal,
    logout,
    activeView,
    setActiveView,
    setSelectedCategory,
    cartCount,
    wishlist,
    lowDataMode,
    toggleLowDataMode,
    language,
    toggleLanguage,
    buyerActiveOrdersCount,
    conversations,
  } = useApp();

  const totalUnreadMessages = conversations.reduce(
    (sum, c) => sum + (currentUser?.role === 'seller' ? c.unreadSeller : c.unreadBuyer),
    0
  );

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-stone-200">
      {/* Strict 1-row, 3-zone Top Bar Contract for Desktop / Tablet */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-4 sm:gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => {
            setActiveView('catalog');
            setSelectedCategory('all');
          }}
          className="text-xl sm:text-2xl font-black font-heading tracking-tight text-[#0c0d10] whitespace-nowrap shrink-0 flex items-center gap-1.5"
        >
          <span>Shop It</span>
          <span className="w-2.5 h-2.5 rounded-sm bg-[#f95700] inline-block" />
          <span className="text-[10px] font-bold text-[#123524] bg-[#ecf5f0] px-2 py-0.5 rounded-md border border-[#bce0cc] ml-0.5">
            NG
          </span>
        </button>

        {/* Zone 2: 4–5 single-line clean text navigation links */}
        <nav className="hidden md:flex items-center gap-5 text-xs sm:text-sm font-semibold text-stone-600">
          <button
            onClick={() => {
              setSelectedCategory('all');
              setActiveView('catalog');
            }}
            className={`whitespace-nowrap transition-colors hover:text-black ${
              activeView === 'catalog' ? 'text-black font-bold' : ''
            }`}
          >
            {language === 'pidgin' ? 'All Market' : 'All Crafts'}
          </button>
          <button
            onClick={() => {
              setSelectedCategory('beads');
              setActiveView('catalog');
            }}
            className="whitespace-nowrap transition-colors hover:text-black"
          >
            {language === 'pidgin' ? 'Waist Beads' : 'Waist Beads'}
          </button>
          <button
            onClick={() => {
              setSelectedCategory('fragrance');
              setActiveView('catalog');
            }}
            className="whitespace-nowrap transition-colors hover:text-black"
          >
            {language === 'pidgin' ? 'Scent & Oils' : 'Fragrance & Mists'}
          </button>
          <button
            onClick={() => {
              setSelectedCategory('bags');
              setActiveView('catalog');
            }}
            className="whitespace-nowrap transition-colors hover:text-black"
          >
            {language === 'pidgin' ? 'Crochet Bags' : 'Crochet & Bags'}
          </button>
          <button
            onClick={() => setActiveView('chat')}
            className={`whitespace-nowrap transition-colors hover:text-black flex items-center gap-1.5 ${
              activeView === 'chat' ? 'text-[#f95700] font-bold' : ''
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Messages</span>
            {totalUnreadMessages > 0 && (
              <span className="w-2 h-2 rounded-full bg-[#f95700]" />
            )}
          </button>
          <button
            onClick={() => setActiveView('orders')}
            className={`whitespace-nowrap transition-colors hover:text-black flex items-center gap-1.5 ${
              activeView === 'orders' ? 'text-black font-bold' : ''
            }`}
          >
            <span>Track Orders</span>
            {buyerActiveOrdersCount > 0 && (
              <span className="w-2 h-2 rounded-full bg-[#123524]" />
            )}
          </button>
          {currentUser?.role === 'admin' && (
            <button
              onClick={() => setActiveView('admin')}
              className={`whitespace-nowrap px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                activeView === 'admin'
                  ? 'bg-[#0c0d10] text-white shadow-xs'
                  : 'bg-stone-100 text-stone-800 hover:bg-stone-200'
              }`}
            >
              Admin Panel
            </button>
          )}
        </nav>

        {/* Zone 3: 1 primary action or action cluster */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Low-data toggle quick pill */}
          <button
            onClick={toggleLowDataMode}
            title={lowDataMode ? 'Low-Data Mode Active (saving MBs)' : 'Click to enable Low-Data Mode'}
            className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
              lowDataMode
                ? 'bg-amber-100 text-amber-900 border border-amber-300'
                : 'text-slate-500 hover:text-slate-800 border border-slate-200'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${lowDataMode ? 'text-amber-600 fill-amber-600' : ''}`} />
            <span>{lowDataMode ? 'Low-Data Mode' : 'Save Data'}</span>
          </button>

          {/* Language toggle */}
          <button
            onClick={toggleLanguage}
            className="hidden sm:inline-block px-2 py-1 text-xs font-semibold text-slate-600 hover:text-slate-900 border border-slate-200 rounded-md"
          >
            {language === 'en' ? 'Pidgin' : 'English'}
          </button>

          {/* Messages button */}
          <button
            onClick={() => setActiveView('chat')}
            aria-label="Messages"
            title="Locked Chat & Inquiries"
            className="relative min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-700 hover:text-black rounded-xl hover:bg-stone-100 transition-colors"
          >
            <MessageSquare className="w-5 h-5 text-stone-700" />
            {totalUnreadMessages > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-[#f95700] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
                {totalUnreadMessages}
              </span>
            )}
          </button>

          {/* Orders Tracking button */}
          <button
            onClick={() => setActiveView('orders')}
            aria-label="Track Orders"
            title="Track Orders & Escrow"
            className="relative min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-700 hover:text-black rounded-xl hover:bg-stone-100 transition-colors"
          >
            <ShieldCheck className="w-5 h-5 text-[#123524]" />
            {buyerActiveOrdersCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-[#123524] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
                {buyerActiveOrdersCount}
              </span>
            )}
          </button>

          {/* Wishlist button */}
          <button
            onClick={() => setActiveView('wishlist')}
            aria-label="Wishlist"
            className="relative min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-700 hover:text-black rounded-xl hover:bg-stone-100 transition-colors"
          >
            <Heart className="w-5 h-5" />
            {wishlist.length > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-[#f95700] text-white text-[10px] font-bold flex items-center justify-center">
                {wishlist.length}
              </span>
            )}
          </button>

          {/* Cart button */}
          <button
            onClick={() => setActiveView('cart')}
            aria-label="Cart"
            className="relative min-w-[42px] min-h-[42px] flex items-center justify-center text-stone-700 hover:text-black rounded-xl hover:bg-stone-100 transition-colors"
          >
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute top-1.5 right-1.5 w-4 h-4 rounded-full bg-[#f95700] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
                {cartCount}
              </span>
            )}
          </button>

          {/* Primary Action Button */}
          {currentUser ? (
            <div className="flex items-center gap-2">
              {currentUser.role === 'admin' ? (
                <button
                  onClick={() => setActiveView('admin')}
                  className="px-3.5 py-2 text-xs sm:text-sm font-bold text-white bg-[#0c0d10] hover:bg-stone-800 rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-xs active:scale-[0.98]"
                >
                  <Shield className="w-4 h-4 text-[#f95700]" />
                  <span>Admin Hub</span>
                </button>
              ) : currentUser.role === 'seller' ? (
                <button
                  onClick={() => setActiveView('seller_dashboard')}
                  className="px-3.5 py-2 text-xs sm:text-sm font-bold text-white bg-[#0c0d10] hover:bg-stone-800 rounded-xl transition-all whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-xs active:scale-[0.98]"
                >
                  <Store className="w-4 h-4 text-[#f95700]" />
                  <span className="hidden sm:inline">Seller Hub</span>
                </button>
              ) : (
                <button
                  onClick={() => openAuthModal('seller_register')}
                  className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-[#f95700] hover:bg-[#e04b00] rounded-xl transition-all whitespace-nowrap shrink-0 shadow-sm active:scale-[0.98]"
                >
                  Start Selling
                </button>
              )}
            </div>
          ) : (
            <button
              onClick={() => openAuthModal('login')}
              className="px-4 py-2 text-xs sm:text-sm font-bold text-white bg-[#0c0d10] hover:bg-stone-800 rounded-xl transition-all whitespace-nowrap shrink-0 shadow-xs active:scale-[0.98]"
            >
              Sign In
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
