import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { formatNaira } from '../utils/pricing';
import { NIGERIAN_BANKS } from '../data/mockData';
import {
  Wallet,
  ArrowUpRight,
  ShieldCheck,
  Clock,
  Plus,
  AlertCircle,
  CheckCircle2,
  Lock,
  Building2,
  Smartphone,
  Info,
  ShieldAlert,
  ArrowDownLeft,
  X,
  FileText,
  KeyRound,
} from 'lucide-react';

export const SellerWalletView: React.FC = () => {
  const {
    currentWallet,
    currentSeller,
    requestWithdrawal,
    addPayoutAccount,
    securityProfile,
    toggleTwoFactor,
    notify,
  } = useApp();

  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);
  const [isAddAccountModalOpen, setIsAddAccountModalOpen] = useState(false);

  // Withdrawal form
  const [withdrawAmount, setWithdrawAmount] = useState<number>(5000);
  const [selectedAccountId, setSelectedAccountId] = useState<string>(
    currentWallet?.activePayoutAccountId || currentWallet?.payoutAccounts[0]?.id || ''
  );
  const [withdrawalOtp, setWithdrawalOtp] = useState('1234');
  const [isWithdrawing, setIsWithdrawing] = useState(false);

  // New payout account form
  const [selectedBankCode, setSelectedBankCode] = useState('OPAY');
  const [accountNumber, setAccountNumber] = useState('');
  const [accountName, setAccountName] = useState(currentSeller?.shopName ? 'AMAKA EZE' : 'STUDENT ARTISAN');

  if (!currentWallet) {
    return (
      <div className="p-8 text-center text-slate-500">
        Wallet data not initialized.
      </div>
    );
  }

  const selectedAccount = currentWallet.payoutAccounts.find(
    p => p.id === (selectedAccountId || currentWallet.activePayoutAccountId)
  );

  const withdrawalFee = withdrawAmount >= 5000 ? 0 : 50;
  const totalDeducted = withdrawAmount + withdrawalFee;

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAccountId && currentWallet.payoutAccounts.length === 0) {
      notify('Please add a payout bank account or Opay first.', 'error');
      return;
    }
    setIsWithdrawing(true);
    setTimeout(() => {
      setIsWithdrawing(false);
      const accId = selectedAccountId || currentWallet.payoutAccounts[0]?.id;
      const success = requestWithdrawal(withdrawAmount, accId, withdrawalOtp);
      if (success) {
        setIsWithdrawModalOpen(false);
      }
    }, 1000);
  };

  const handleAddAccountSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const bank = NIGERIAN_BANKS.find(b => b.code === selectedBankCode);
    if (!bank) return;
    if (accountNumber.length !== 10) {
      notify('Nigerian bank/Opay account numbers must be 10 digits.', 'error');
      return;
    }
    addPayoutAccount(bank.code, bank.name, accountNumber, accountName);
    setIsAddAccountModalOpen(false);
    setAccountNumber('');
  };

  return (
    <div className="space-y-6">
      {/* Wallet Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
        {/* Available Balance (Withdrawable) */}
        <div className="bg-[#0C0D0E] text-white rounded-3xl p-6 sm:p-7 relative overflow-hidden shadow-lg border border-slate-800">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#22382B] text-[#86EFAC] flex items-center justify-center font-bold">
                ₦
              </div>
              <span className="text-xs font-semibold text-slate-300">Available Balance</span>
            </div>
            <span className="text-[11px] font-bold text-[#86EFAC] bg-[#1D3125] px-2.5 py-0.5 rounded-md border border-[#2D4D3A]">
              Ready to Withdraw
            </span>
          </div>

          <div className="py-4">
            <div className="text-3xl sm:text-4xl font-black font-mono-numbers tracking-tight text-white">
              {formatNaira(currentWallet.availableBalance)}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Released from completed deliveries. Minimum withdrawal: ₦1,000.
            </p>
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              onClick={() => setIsWithdrawModalOpen(true)}
              disabled={currentWallet.availableBalance < 1000 || currentWallet.isFrozen}
              className="px-5 py-2.5 bg-[#F95700] hover:bg-[#E04B00] disabled:bg-slate-700 text-white font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md shadow-[#F95700]/20 flex items-center gap-2 active:scale-98"
            >
              <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              <span>Withdraw Funds</span>
            </button>

            <button
              onClick={() => setIsAddAccountModalOpen(true)}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold transition-all border border-slate-700 flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Bank / Opay</span>
            </button>
          </div>
        </div>

        {/* Pending Escrow Balance */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-600" />
                <span className="text-xs font-bold text-slate-700">Pending in Escrow</span>
              </div>
              <span className="text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded-md border border-amber-200">
                Buyer Protected
              </span>
            </div>

            <div className="py-4">
              <div className="text-3xl sm:text-4xl font-black font-mono-numbers tracking-tight text-slate-900">
                {formatNaira(currentWallet.pendingBalance)}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                Held safely until the campus buyer taps <strong>"Item Received"</strong> or 5 days elapse.
              </p>
            </div>
          </div>

          <div className="p-3 bg-[#EAF3EE] rounded-xl border border-[#D1E7DD] text-xs text-[#1D382A] flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#2D5A40] shrink-0" />
            <span>
              <strong>Double-Entry Ledger: </strong>
              Every Naira is accounted for with an immutable audit trail.
            </span>
          </div>
        </div>
      </div>

      {/* Wallet Status Notice (Frozen or Limits) */}
      {currentWallet.isFrozen && (
        <div className="p-4 bg-rose-50 border border-rose-300 rounded-2xl flex items-center gap-3 text-rose-900 text-xs">
          <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0" />
          <div>
            <strong>Wallet Frozen by Admin: </strong>
            {currentWallet.freezeReason || 'Temporary security review'}. Payouts are paused until cleared.
          </div>
        </div>
      )}

      {/* Payout Bank Accounts Strip */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-600" />
            <h3 className="text-sm font-bold text-slate-900">Verified Payout Accounts</h3>
          </div>
          <button
            onClick={() => setIsAddAccountModalOpen(true)}
            className="text-xs font-bold text-[#F95700] hover:underline flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Account</span>
          </button>
        </div>

        {currentWallet.payoutAccounts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {currentWallet.payoutAccounts.map(acc => {
              const inCooling = new Date(acc.coolingPeriodEndsAt).getTime() > Date.now();
              return (
                <div
                  key={acc.id}
                  className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/70 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <div className="flex items-center gap-1.5 font-bold text-slate-900">
                      <span>{acc.bankName}</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded font-semibold">
                        Verified
                      </span>
                    </div>
                    <div className="text-xs text-slate-600 font-mono-numbers mt-0.5">
                      {acc.accountNumber} · {acc.accountName}
                    </div>
                    {inCooling && (
                      <span className="text-[10px] text-amber-700 font-medium block mt-1">
                        ⚠️ 24-hr security cooling period active
                      </span>
                    )}
                  </div>

                  <span className="text-[11px] font-semibold text-slate-500">Default</span>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-xs text-slate-500 italic py-2">
            No payout accounts linked yet. Link your Opay or bank account to withdraw sales.
          </div>
        )}
      </div>

      {/* Append-Only Transaction Ledger */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs space-y-0">
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900 flex items-center gap-2">
              <FileText className="w-4 h-4 text-slate-600" />
              <span>Financial Ledger & Audit Trail</span>
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Append-only double-entry records for sales, escrow releases, and withdrawals.
            </p>
          </div>
          <span className="text-xs font-mono-numbers text-slate-500">
            {currentWallet.transactions.length} entries
          </span>
        </div>

        {currentWallet.transactions.length > 0 ? (
          <div className="divide-y divide-slate-100 text-xs">
            {currentWallet.transactions.map(txn => {
              const isCredit = txn.type === 'escrow_release';
              const isDebit = txn.type === 'withdrawal';
              const isPending = txn.type === 'sale_pending';

              return (
                <div key={txn.id} className="p-4 flex items-center justify-between gap-3 hover:bg-slate-50/60 transition-colors">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold shrink-0 ${
                        isCredit
                          ? 'bg-[#EAF3EE] text-[#22382B]'
                          : isDebit
                          ? 'bg-slate-100 text-slate-800'
                          : 'bg-amber-50 text-amber-800'
                      }`}
                    >
                      {isCredit && <ArrowDownLeft className="w-4 h-4 text-[#2D5A40]" />}
                      {isDebit && <ArrowUpRight className="w-4 h-4 text-slate-700" />}
                      {isPending && <Clock className="w-4 h-4 text-amber-600" />}
                    </div>

                    <div>
                      <div className="font-bold text-slate-900">{txn.description}</div>
                      <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-2">
                        <span className="font-mono">{txn.id}</span>
                        <span aria-hidden="true">·</span>
                        <span>{txn.createdAt}</span>
                        {txn.fee > 0 && <span>· Fee: {formatNaira(txn.fee)}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div
                      className={`font-black font-mono-numbers text-sm ${
                        isCredit
                          ? 'text-[#22382B]'
                          : isDebit
                          ? 'text-slate-900'
                          : 'text-amber-700'
                      }`}
                    >
                      {isDebit ? '-' : '+'}
                      {formatNaira(txn.amount)}
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono-numbers">
                      Bal: {formatNaira(txn.balanceAfter)}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center text-xs text-slate-400">
            No wallet transactions recorded yet.
          </div>
        )}
      </div>

      {/* Security Hardening & 2FA Strip */}
      <div className="bg-[#22382B] text-white rounded-2xl p-5 border border-[#335340] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-[#86EFAC]" />
            <h4 className="text-sm font-bold text-white">Seller 2FA Security Protection</h4>
          </div>
          <p className="text-xs text-slate-300 mt-1 max-w-lg">
            Required for all student artisans withdrawing funds. Every payout and payout-account change requires an SMS OTP code sent to your registered phone.
          </p>
        </div>

        <button
          onClick={toggleTwoFactor}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 ${
            securityProfile.twoFactorEnabled
              ? 'bg-[#86EFAC] text-[#122419] hover:bg-[#6EE7B7]'
              : 'bg-white text-slate-900 hover:bg-slate-100'
          }`}
        >
          {securityProfile.twoFactorEnabled ? '2FA Active (Protected)' : 'Enable 2FA'}
        </button>
      </div>

      {/* WITHDRAW MODAL */}
      {isWithdrawModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                <ArrowUpRight className="w-5 h-5 text-[#F95700]" />
                <span>Withdraw to Nigerian Bank / Opay</span>
              </h3>
              <button
                onClick={() => setIsWithdrawModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleWithdrawSubmit} className="space-y-4 text-xs">
              {/* Amount */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Withdrawal Amount (₦) *
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">
                    ₦
                  </span>
                  <input
                    type="number"
                    step={500}
                    min={1000}
                    max={currentWallet.availableBalance}
                    required
                    value={withdrawAmount}
                    onChange={e => setWithdrawAmount(Number(e.target.value))}
                    className="w-full h-11 pl-9 pr-3 rounded-xl border border-slate-200 text-sm font-bold font-mono-numbers text-slate-900 focus:outline-none focus:ring-2 focus:ring-[#F95700]"
                  />
                </div>
                <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                  <span>Available: {formatNaira(currentWallet.availableBalance)}</span>
                  <span className="text-[#22382B] font-semibold">
                    {withdrawAmount >= 5000 ? 'Free (Shop It pays transfer fee)' : '₦50 fee below ₦5,000'}
                  </span>
                </div>
              </div>

              {/* Select Payout Destination */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Select Payout Account *
                </label>
                {currentWallet.payoutAccounts.length > 0 ? (
                  <select
                    value={selectedAccountId}
                    onChange={e => setSelectedAccountId(e.target.value)}
                    className="w-full h-11 px-3 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-900"
                  >
                    {currentWallet.payoutAccounts.map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.bankName} - {acc.accountNumber} ({acc.accountName})
                      </option>
                    ))}
                  </select>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setIsWithdrawModalOpen(false);
                      setIsAddAccountModalOpen(true);
                    }}
                    className="w-full p-3 border-2 border-dashed border-amber-300 rounded-xl text-center text-amber-900 font-bold hover:bg-amber-50"
                  >
                    + Add Bank Account or Opay First
                  </button>
                )}
              </div>

              {/* 4-Digit OTP Simulation */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5">
                    <KeyRound className="w-3.5 h-3.5 text-slate-600" />
                    <span>Security SMS OTP *</span>
                  </span>
                  <span className="text-[10px] text-slate-500">Sent to seller phone</span>
                </div>
                <input
                  type="text"
                  maxLength={4}
                  required
                  value={withdrawalOtp}
                  onChange={e => setWithdrawalOtp(e.target.value)}
                  placeholder="1234"
                  className="w-32 h-10 px-3 tracking-widest text-center text-lg font-bold font-mono-numbers rounded-lg border border-slate-300 bg-white text-slate-900 mx-auto block"
                />
                <span className="text-[10px] text-slate-400 block text-center">
                  Demo withdrawal verification code is prefilled as <strong>1234</strong>
                </span>
              </div>

              {/* Fee and Payout Summary */}
              <div className="pt-2 border-t border-slate-100 text-xs text-slate-600 space-y-1">
                <div className="flex justify-between">
                  <span>Transfer Amount</span>
                  <span className="font-mono-numbers font-medium text-slate-900">{formatNaira(withdrawAmount)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Paystack Transfer Network Fee</span>
                  <span className="font-mono-numbers font-medium text-emerald-800">
                    {withdrawalFee === 0 ? '₦0 (Paid by Shop It)' : formatNaira(withdrawalFee)}
                  </span>
                </div>
                <div className="flex justify-between font-bold text-slate-900 pt-1 border-t border-slate-100">
                  <span>Total Deducted from Balance</span>
                  <span className="font-mono-numbers text-sm">{formatNaira(totalDeducted)}</span>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsWithdrawModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isWithdrawing}
                  className="px-5 py-2.5 bg-[#F95700] hover:bg-[#E04B00] text-white font-bold rounded-xl shadow-md shadow-[#F95700]/20 transition-all flex items-center gap-2"
                >
                  {isWithdrawing ? 'Processing payout...' : `Confirm & Withdraw ${formatNaira(withdrawAmount)}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADD PAYOUT ACCOUNT MODAL */}
      {isAddAccountModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-7 space-y-5 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-slate-900" />
                <span>Link Payout Account</span>
              </h3>
              <button
                onClick={() => setIsAddAccountModalOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddAccountSubmit} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Select Bank / Fintech *</label>
                <select
                  value={selectedBankCode}
                  onChange={e => setSelectedBankCode(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-slate-200 bg-white text-xs font-semibold text-slate-900"
                >
                  {NIGERIAN_BANKS.map(b => (
                    <option key={b.code} value={b.code}>
                      {b.icon} {b.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  10-Digit Account Number *
                </label>
                <input
                  type="text"
                  maxLength={10}
                  required
                  value={accountNumber}
                  onChange={e => setAccountNumber(e.target.value.replace(/\D/g, ''))}
                  placeholder="e.g. 8098765432"
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-sm font-bold font-mono-numbers text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  Verified Account Name *
                </label>
                <input
                  type="text"
                  required
                  value={accountName}
                  onChange={e => setAccountName(e.target.value.toUpperCase())}
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-900 uppercase"
                />
                <span className="text-[11px] text-slate-500 mt-1 block">
                  Per security rules, account name must match your verified student/guardian ID.
                </span>
              </div>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>24-Hour Cooling Period: </strong>
                  Newly added accounts require a 24-hour review delay before withdrawals can be initiated to prevent account takeover theft.
                </span>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddAccountModalOpen(false)}
                  className="px-4 py-2 font-medium text-slate-600 hover:text-slate-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#0C0D0E] hover:bg-[#1E1F22] text-white font-bold rounded-xl shadow-xs transition-all"
                >
                  Verify & Save Account
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
