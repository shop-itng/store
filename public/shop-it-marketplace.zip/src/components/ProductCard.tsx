import React, { useState } from 'react';
import { Product } from '../types';
import { useApp } from '../context/AppContext';
import { formatNaira } from '../utils/pricing';
import { Heart, Star, Sparkles, MapPin, ShieldCheck, ImageOff } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { openProduct, wishlist, toggleWishlist, lowDataMode, openSellerShop } = useApp();
  const [imageError, setImageError] = useState(false);
  const isWishlisted = wishlist.includes(product.id);

  const mainImage = product.images[0] || '';

  return (
    <article
      onClick={() => openProduct(product.id)}
      className="group relative bg-white rounded-2xl border border-slate-200 overflow-hidden cursor-pointer transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md hover:border-slate-300 flex flex-col h-full"
    >
      {/* Visual Asset Container */}
      <div className="relative aspect-4/3 w-full bg-slate-100 overflow-hidden">
        {lowDataMode ? (
          /* Low-Data Mode representation to preserve mobile data */
          <div className="w-full h-full flex flex-col items-center justify-center p-4 bg-slate-100 text-slate-500 text-center">
            <span className="text-2xl mb-1">
              {product.category === 'beads' ? '📿' : product.category === 'fragrance' ? '🌿' : '🧶'}
            </span>
            <span className="text-xs font-medium text-slate-700 line-clamp-1">{product.title}</span>
            <span className="text-[10px] text-[#F95700] font-bold mt-1">Low-Data Preview</span>
          </div>
        ) : !imageError && mainImage ? (
          <img
            src={mainImage}
            alt={product.title}
            referrerPolicy="no-referrer"
            loading="lazy"
            onError={() => setImageError(true)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-103"
          />
        ) : (
          /* Zero-broken-image fallback */
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 p-4 text-slate-400">
            <ImageOff className="w-8 h-8 mb-1 stroke-1" />
            <span className="text-xs font-medium text-slate-500">{product.category.toUpperCase()}</span>
          </div>
        )}

        {/* Top Floating Actions: Wishlist Heart & Availability Status */}
        <div className="absolute top-2.5 left-2.5 right-2.5 flex items-center justify-between pointer-events-none">
          <div>
            {product.isSoldOut ? (
              <span className="pointer-events-auto bg-[#0C0D0E]/90 text-white text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                Sold Out
              </span>
            ) : product.isNewArrival ? (
              <span className="pointer-events-auto bg-[#1D3125] text-[#86EFAC] border border-[#2D4D3A] text-[10px] sm:text-[11px] font-bold px-2 py-0.5 rounded-md backdrop-blur-xs">
                New Arrival
              </span>
            ) : null}
          </div>

          <button
            type="button"
            onClick={e => {
              e.stopPropagation();
              toggleWishlist(product.id);
            }}
            aria-label={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
            className="pointer-events-auto min-w-[36px] min-h-[36px] rounded-xl bg-white/95 backdrop-blur-sm flex items-center justify-center text-stone-700 hover:text-[#f95700] border border-stone-200/60 shadow-xs transition-transform active:scale-90"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${
                isWishlisted ? 'fill-[#f95700] text-[#f95700]' : 'text-stone-600'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Card Content & Metadata */}
      <div className="p-3.5 sm:p-4 flex flex-col flex-1 justify-between gap-2.5">
        <div>
          {/* Seller Shop & Campus Metadata */}
          <div className="flex items-center gap-1.5 text-xs text-slate-500 mb-1">
            <span
              onClick={e => {
                e.stopPropagation();
                openSellerShop(product.sellerId);
              }}
              className="font-semibold text-slate-700 hover:text-[#F95700] hover:underline truncate"
            >
              {product.sellerShopName}
            </span>
            <span aria-hidden="true" className="text-slate-400">·</span>
            <span className="truncate text-slate-500">{product.sellerCampus}</span>
          </div>

          {/* Product Title */}
          <h3 className="text-sm sm:text-base font-bold text-[#0C0D0E] line-clamp-2 leading-snug group-hover:text-[#F95700] transition-colors">
            {product.title}
          </h3>
        </div>

        {/* Price & Rating Bar */}
        <div className="pt-2 border-t border-slate-100 flex items-baseline justify-between gap-2">
          <div>
            <div className="text-base sm:text-lg font-black text-[#0C0D0E] font-mono-numbers tracking-tight">
              {formatNaira(product.displayPrice)}
            </div>
            <div className="text-[11px] text-[#22382B] font-semibold font-mono-numbers">
              Incl. {formatNaira(product.serviceFee)} protection
            </div>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-1 text-xs text-slate-600 font-semibold">
            <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
            <span className="font-mono-numbers">{product.rating.toFixed(1)}</span>
            <span className="text-slate-400 font-normal">({product.reviewCount})</span>
          </div>
        </div>
      </div>
    </article>
  );
};
