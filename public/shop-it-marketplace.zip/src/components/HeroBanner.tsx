import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, ArrowRight, ShieldCheck, MapPin } from 'lucide-react';

export const HeroBanner: React.FC = () => {
  const { setSelectedCategory, language, lowDataMode } = useApp();

  return (
    <section className="bg-[#0C0D0E] text-white rounded-3xl overflow-hidden border border-slate-800 shadow-md relative">
      <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch min-h-[360px] sm:min-h-[400px]">
        {/* Left Column: Hero Copy */}
        <div className="lg:col-span-7 p-6 sm:p-10 lg:p-12 flex flex-col justify-between z-10 space-y-6">
          <div className="space-y-4">
            {/* Editorial kicker */}
            <div className="flex items-center gap-2 text-xs font-bold text-[#F95700]">
              <Sparkles className="w-4 h-4 text-[#F95700]" />
              <span className="uppercase tracking-wider">
                {language === 'pidgin'
                  ? 'Bespoke Student Crafts · Verified Naija Campuses'
                  : 'Student Artisan Marketplace · Escrow Protected'}
              </span>
            </div>

            {/* Headline in Outfit */}
            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight leading-[1.12] max-w-xl text-white">
              {language === 'pidgin' ? (
                <>
                  Original handmade beads, perfume oil & crochet straight from campus creatives.
                </>
              ) : (
                <>
                  Handmade waist beads, dorm scents & crochet crafted by Nigerian students.
                </>
              )}
            </h1>

            <p className="text-slate-300 text-xs sm:text-sm max-w-lg leading-relaxed">
              Discover unique handmade items by student creators across UNILAG, UI, UNILORIN, UNN & Covenant.
              Payment stays protected in Shop It escrow until you hold your craft.
            </p>
          </div>

          {/* Quick CTA Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => setSelectedCategory('beads')}
              className="px-5 py-3 bg-[#F95700] hover:bg-[#E04B00] text-white font-bold rounded-xl text-xs sm:text-sm transition-all flex items-center gap-2 shadow-lg shadow-[#F95700]/25 active:scale-98"
            >
              <span>Explore Waist Beads</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>

            <button
              onClick={() => setSelectedCategory('fragrance')}
              className="px-4 py-3 bg-[#18281E] hover:bg-[#22382B] text-[#D1E7DD] font-semibold rounded-xl text-xs sm:text-sm border border-[#2D4D3A] transition-all active:scale-98"
            >
              Dorm Scents & Mists
            </button>

            <button
              onClick={() => setSelectedCategory('bags')}
              className="px-4 py-3 bg-slate-900/90 hover:bg-slate-800 text-slate-200 font-semibold rounded-xl text-xs sm:text-sm border border-slate-800 transition-all active:scale-98"
            >
              Crochet Bags
            </button>
          </div>

          {/* Micro trust markers */}
          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-400 pt-3 border-t border-slate-800/80">
            <div className="flex items-center gap-1.5 text-[#86EFAC]">
              <ShieldCheck className="w-4 h-4 text-[#86EFAC] shrink-0" />
              <span>Naira Escrow Protection</span>
            </div>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <div className="flex items-center gap-1.5 text-amber-400">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Campus Quad Pickups</span>
            </div>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span className="text-slate-400">Guardian-Verified Teen Payouts</span>
          </div>
        </div>

        {/* Right Column: Hero Visual Showcase */}
        {!lowDataMode && (
          <div className="lg:col-span-5 relative hidden lg:block overflow-hidden">
            <img
              src="/src/assets/images/hero_african_beads_craft_1792510477996.jpg"
              alt="Handcrafted African waist beads and jewelry"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[#0C0D0E] via-transparent to-transparent" />
            <div className="absolute bottom-4 right-4 bg-[#0C0D0E]/85 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-slate-700 text-[11px] text-slate-300">
              Hand-strung by UNILAG Student Artisans
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
