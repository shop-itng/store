import React from 'react';
import { useApp } from '../context/AppContext';
import { Shield, User, Store, Zap, Globe, MessageSquare, Download } from 'lucide-react';

export const RoleSwitcherBar: React.FC = () => {
  const {
    currentUser,
    switchRole,
    lowDataMode,
    toggleLowDataMode,
    language,
    toggleLanguage,
    activeView,
    setActiveView,
  } = useApp();

  return (
    <div className="bg-[#0c0d10] text-stone-300 text-xs py-1.5 px-3 sm:px-6 border-b border-stone-800">
      <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="text-stone-400 font-semibold hidden sm:inline text-[11px] uppercase tracking-wider">
            Evaluation Role:
          </span>
          <div className="flex items-center gap-1 bg-stone-900 p-0.5 rounded-xl border border-stone-800">
            <button
              onClick={() => {
                switchRole('buyer');
                setActiveView('catalog');
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                currentUser?.role === 'buyer'
                  ? 'bg-[#123524] text-white shadow-xs'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Buyer
            </button>
            <button
              onClick={() => {
                switchRole('seller');
                setActiveView('seller_dashboard');
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                currentUser?.role === 'seller'
                  ? 'bg-[#f95700] text-white shadow-xs'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Seller
            </button>
            <button
              onClick={() => {
                switchRole('admin');
                setActiveView('admin');
              }}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                currentUser?.role === 'admin'
                  ? 'bg-amber-400 text-black font-bold shadow-xs'
                  : 'text-stone-400 hover:text-white'
              }`}
            >
              Admin Panel
            </button>
          </div>
          <span className="text-stone-400 text-[11px] hidden md:inline">
            ({currentUser?.name || 'Guest'} · {currentUser?.role === 'seller' ? 'Shop Owner' : currentUser?.role})
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Download Codebase ZIP Button */}
          <a
            href="/shop-it-marketplace.zip"
            download="shop-it-marketplace.zip"
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold bg-[#f95700] hover:bg-[#e04b00] text-white transition-all shadow-xs active:scale-95"
            title="Download full application source code as ZIP"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download ZIP</span>
          </a>

          {/* Quick Chat Shortcut */}
          <button
            onClick={() => setActiveView('chat')}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors ${
              activeView === 'chat'
                ? 'bg-[#123524] text-white'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Chat View</span>
          </button>

          {/* Low-data toggle */}
          <button
            onClick={toggleLowDataMode}
            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] transition-colors ${
              lowDataMode
                ? 'bg-[#fff2ea] text-[#f95700] border border-[#fed7aa] font-bold'
                : 'text-stone-400 hover:text-stone-200'
            }`}
          >
            <Zap className="w-3 h-3" />
            <span>{lowDataMode ? 'Low-Data: ON' : 'Low-Data: OFF'}</span>
          </button>

          {/* Language toggle */}
          <button
            onClick={toggleLanguage}
            className="flex items-center gap-1 px-2 py-0.5 rounded-lg text-[11px] text-stone-300 hover:text-white"
          >
            <Globe className="w-3 h-3" />
            <span>{language === 'en' ? 'EN' : 'Pidgin'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
