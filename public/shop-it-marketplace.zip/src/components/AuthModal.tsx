import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Campus, UserRole } from '../types';
import { CAMPUSES, DEMO_USERS } from '../data/mockData';
import {
  X,
  Phone,
  Mail,
  ShieldCheck,
  Store,
  User,
  CheckCircle2,
  Lock,
  Sparkles,
  ArrowRight,
  AlertCircle,
} from 'lucide-react';

export const AuthModal: React.FC = () => {
  const {
    isAuthModalOpen,
    closeAuthModal,
    authTab,
    setAuthTab,
    pendingAuthData,
    setPendingAuthData,
    verifyOtp,
    submitSellerRegistration,
    login,
    notify,
  } = useApp();

  // Signup form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('buyer');

  // OTP state
  const [otpCode, setOtpCode] = useState('1234');
  const [resendCooldown, setResendCooldown] = useState(30);

  // Seller registration specifics
  const [shopName, setShopName] = useState('');
  const [campus, setCampus] = useState<Campus>('UNILAG (Akoka)');
  const [bio, setBio] = useState('');
  const [under18, setUnder18] = useState(false);
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');

  if (!isAuthModalOpen) return null;

  const handleInitialSignup = (e: React.FormEvent) => {
    e.preventDefault();

    if (!phone.startsWith('+234') && !phone.startsWith('0')) {
      notify('Please enter a valid Nigerian phone number (e.g., 08123456789 or +234...)', 'error');
      return;
    }

    const authData = {
      name,
      email,
      phone,
      role,
    };
    setPendingAuthData(authData);
    setAuthTab('otp');
    notify(`SMS verification OTP sent to ${phone}`, 'info');
  };

  const handleOtpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    verifyOtp(otpCode);
  };

  const handleSellerFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (under18 && (!guardianName || !guardianPhone)) {
      notify('Artisans under 18 require a verified guardian name and phone number for payouts.', 'error');
      return;
    }

    submitSellerRegistration({
      shopName,
      campus,
      bio,
      under18,
      guardianName: under18 ? guardianName : undefined,
      guardianPhone: under18 ? guardianPhone : undefined,
    });
  };

  const handleDemoQuickLogin = (demoRole: 'buyer' | 'seller' | 'admin') => {
    const user = DEMO_USERS[demoRole];
    login(user);
    closeAuthModal();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-6 shadow-2xl relative">
        {/* Close Button */}
        <button
          onClick={closeAuthModal}
          className="absolute top-5 right-5 text-slate-400 hover:text-slate-700 min-h-[38px] min-w-[38px] flex items-center justify-center rounded-full hover:bg-slate-100 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        {authTab !== 'otp' && authTab !== 'seller_register' && (
          <div className="flex border-b border-slate-100 pb-3">
            <button
              onClick={() => setAuthTab('login')}
              className={`flex-1 text-center py-2 text-sm font-bold border-b-2 transition-all ${
                authTab === 'login'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setAuthTab('signup')}
              className={`flex-1 text-center py-2 text-sm font-bold border-b-2 transition-all ${
                authTab === 'signup'
                  ? 'border-slate-900 text-slate-900'
                  : 'border-transparent text-slate-400 hover:text-slate-600'
              }`}
            >
              Create Account
            </button>
          </div>
        )}

        {/* Tab 1: SIGN IN */}
        {authTab === 'login' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-xl font-black text-slate-900">Welcome to Shop It</h2>
              <p className="text-xs text-slate-500 mt-1">
                Nigeria's marketplace for campus handmade crafts.
              </p>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                handleDemoQuickLogin('buyer');
              }}
              className="space-y-3"
            >
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Email or Phone (+234)
                </label>
                <input
                  type="text"
                  required
                  defaultValue="tobi.ade@campus.ng"
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Password
                </label>
                <input
                  type="password"
                  required
                  defaultValue="••••••••"
                  className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
                />
              </div>

              <button
                type="submit"
                className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md shadow-slate-900/10"
              >
                Sign In
              </button>
            </form>

            {/* Quick Demo Switchers */}
            <div className="pt-4 border-t border-slate-100">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2 text-center">
                Instant Demo Logins
              </span>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => handleDemoQuickLogin('buyer')}
                  className="p-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-center transition-colors"
                >
                  <div className="text-xs font-bold text-slate-900">Tobi Ade</div>
                  <div className="text-[10px] text-slate-500">Student Buyer</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoQuickLogin('seller')}
                  className="p-2 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg text-center transition-colors"
                >
                  <div className="text-xs font-bold text-emerald-950">Amaka Beads</div>
                  <div className="text-[10px] text-emerald-700">Student Seller</div>
                </button>
                <button
                  type="button"
                  onClick={() => handleDemoQuickLogin('admin')}
                  className="p-2 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 rounded-lg text-center transition-colors"
                >
                  <div className="text-xs font-bold text-indigo-950">Kazeem</div>
                  <div className="text-[10px] text-indigo-700">Admin Mode</div>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: SIGN UP */}
        {authTab === 'signup' && (
          <form onSubmit={handleInitialSignup} className="space-y-4">
            <div>
              <h2 className="text-xl font-black text-slate-900">Join Shop It</h2>
              <p className="text-xs text-slate-500 mt-1">
                Buy or sell handmade beads, scents, and fashion with fellow Nigerian students.
              </p>
            </div>

            {/* Account Type Selector */}
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => setRole('buyer')}
                className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  role === 'buyer'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                <span>Student Buyer</span>
              </button>
              <button
                type="button"
                onClick={() => setRole('seller')}
                className={`py-2 text-xs font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 ${
                  role === 'seller'
                    ? 'bg-white text-emerald-900 shadow-xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Store className="w-3.5 h-3.5 text-emerald-600" />
                <span>Student Seller</span>
              </button>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Chisom Okonkwo"
                className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">Campus Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="name@unilag.edu.ng or gmail.com"
                className="w-full h-11 px-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Nigerian Phone Number (+234)
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-500">
                  🇳🇬
                </span>
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  placeholder="080 1234 5678"
                  className="w-full h-11 pl-10 pr-3.5 rounded-xl border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
                />
              </div>
              <span className="text-[11px] text-slate-500 mt-1 block">
                We'll send a 4-digit verification OTP code to confirm your number.
              </span>
            </div>

            <button
              type="submit"
              className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs sm:text-sm transition-all flex items-center justify-center gap-1.5"
            >
              <span>Continue with Phone OTP</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Tab 3: OTP VERIFICATION */}
        {authTab === 'otp' && (
          <form onSubmit={handleOtpSubmit} className="space-y-4">
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <h2 className="text-xl font-black text-slate-900">Verify Phone Number</h2>
              <p className="text-xs text-slate-500">
                Enter the 4-digit code sent to <strong className="text-slate-800">{pendingAuthData?.phone || phone}</strong>
              </p>
            </div>

            <div className="py-2">
              <input
                type="text"
                maxLength={4}
                autoFocus
                required
                value={otpCode}
                onChange={e => setOtpCode(e.target.value)}
                placeholder="1234"
                className="w-36 h-12 mx-auto tracking-widest text-center text-2xl font-black rounded-xl border-2 border-slate-900 text-slate-900 block focus:outline-none focus:ring-2 focus:ring-slate-900 font-mono-numbers"
              />
              <span className="text-[11px] text-slate-400 text-center block mt-2">
                Demo code is prefilled as <strong>1234</strong>
              </span>
            </div>

            <button
              type="submit"
              className="w-full h-11 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs sm:text-sm transition-all"
            >
              Verify OTP
            </button>

            <div className="text-center">
              <button
                type="button"
                onClick={() => setAuthTab('signup')}
                className="text-xs text-slate-500 hover:text-slate-800 underline"
              >
                Change Phone Number
              </button>
            </div>
          </form>
        )}

        {/* Tab 4: SELLER ID & UNDER-18 GUARDIAN SETUP */}
        {authTab === 'seller_register' && (
          <form onSubmit={handleSellerFormSubmit} className="space-y-4 max-h-[75vh] overflow-y-auto pr-1">
            <div>
              <div className="flex items-center gap-1.5 text-emerald-700 text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Artisan Onboarding</span>
              </div>
              <h2 className="text-xl font-black text-slate-900">Set Up Your Campus Shop</h2>
              <p className="text-xs text-slate-500 mt-1">
                Nigeria Data Protection Act & Student Safety Compliant.
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Shop Brand Name *
              </label>
              <input
                type="text"
                required
                value={shopName}
                onChange={e => setShopName(e.target.value)}
                placeholder="e.g. Sparkle Waist Beads & Crafts"
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-xs sm:text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Your Primary Campus *
              </label>
              <select
                value={campus}
                onChange={e => setCampus(e.target.value as Campus)}
                className="w-full h-10 px-3 rounded-lg border border-slate-200 text-xs text-slate-900 bg-white"
              >
                {CAMPUSES.filter(c => c !== 'All Campuses').map(c => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Shop Bio / Speciality
              </label>
              <textarea
                rows={2}
                value={bio}
                onChange={e => setBio(e.target.value)}
                placeholder="Tell students what you handcraft (e.g. customized crystal beads, long-lasting room fragrances)..."
                className="w-full p-2.5 rounded-lg border border-slate-200 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900"
              />
            </div>

            {/* Under-18 Guardian Consent Module */}
            <div className="p-3.5 bg-amber-50/80 border border-amber-200 rounded-xl space-y-3">
              <label className="flex items-start gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={under18}
                  onChange={e => setUnder18(e.target.checked)}
                  className="mt-0.5 rounded text-amber-700"
                />
                <span className="text-xs text-amber-950 font-medium">
                  <strong>I am a teenager under 18 years old.</strong> (Requires parent or legal guardian consent. Payouts are made directly to a verified guardian bank/Opay account).
                </span>
              </label>

              {under18 && (
                <div className="space-y-2 pt-2 border-t border-amber-200/80">
                  <div>
                    <label className="text-[11px] font-semibold text-amber-950 block mb-0.5">
                      Parent / Guardian Full Legal Name *
                    </label>
                    <input
                      type="text"
                      required={under18}
                      value={guardianName}
                      onChange={e => setGuardianName(e.target.value)}
                      placeholder="e.g. Mrs. Folashade Adebisi"
                      className="w-full h-9 px-2.5 rounded-md border border-amber-300 bg-white text-xs text-slate-900"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-semibold text-amber-950 block mb-0.5">
                      Guardian Phone / BVN Linked Phone *
                    </label>
                    <input
                      type="tel"
                      required={under18}
                      value={guardianPhone}
                      onChange={e => setGuardianPhone(e.target.value)}
                      placeholder="+2348033001122"
                      className="w-full h-9 px-2.5 rounded-md border border-amber-300 bg-white text-xs text-slate-900 font-mono-numbers"
                    />
                  </div>
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-start gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>
                <strong>ID Verification:</strong> Student ID is reviewed by our campus moderators before your listings go live to guarantee buyer trust.
              </span>
            </div>

            <button
              type="submit"
              className="w-full h-11 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs sm:text-sm transition-all shadow-md shadow-emerald-700/10"
            >
              Launch My Campus Shop
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
