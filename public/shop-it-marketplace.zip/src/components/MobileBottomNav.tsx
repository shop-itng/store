import React from 'react';
import { useApp } from '../context/AppContext';
import { Compass, ShoppingBag, Shield, Store, MessageSquare, ShieldAlert } from 'lucide-react';

export const MobileBottomNav: React.FC = () => {
  const {
    activeView,
    setActiveView,
    cartCount,
    currentUser,
    openAuthModal,
    buyerActiveOrdersCount,
    conversations,
  } = useApp();

  const totalUnreadMessages = conversations.reduce(
    (sum, c) => sum + (currentUser?.role === 'seller' ? c.unreadSeller : c.unreadBuyer),
    0
  );

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200 shadow-lg">
      <div className="grid grid-cols-5 items-center h-16 max-w-md mx-auto px-1">
        {/* Tab 1: Shop */}
        <button
          onClick={() => setActiveView('catalog')}
          className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeView === 'catalog' ? 'text-[#0c0d10] font-bold' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Compass className={`w-5 h-5 ${activeView === 'catalog' ? 'stroke-[2.5] text-[#f95700]' : ''}`} />
          <span className="text-[10px] tracking-tight mt-1">Market</span>
        </button>

        {/* Tab 2: Orders Tracking & Escrow */}
        <button
          onClick={() => setActiveView('orders')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeView === 'orders' ? 'text-[#0c0d10] font-bold' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Shield className={`w-5 h-5 ${activeView === 'orders' ? 'stroke-[2.5] text-[#123524]' : ''}`} />
          {buyerActiveOrdersCount > 0 && (
            <span className="absolute top-1 right-2.5 w-4 h-4 rounded-full bg-[#123524] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
              {buyerActiveOrdersCount}
            </span>
          )}
          <span className="text-[10px] tracking-tight mt-1">Orders</span>
        </button>

        {/* Tab 3: Locked Chat Messages */}
        <button
          onClick={() => setActiveView('chat')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeView === 'chat' ? 'text-[#0c0d10] font-bold' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <MessageSquare className={`w-5 h-5 ${activeView === 'chat' ? 'stroke-[2.5] text-[#f95700]' : ''}`} />
          {totalUnreadMessages > 0 && (
            <span className="absolute top-1 right-2.5 w-4 h-4 rounded-full bg-[#f95700] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
              {totalUnreadMessages}
            </span>
          )}
          <span className="text-[10px] tracking-tight mt-1">Chat</span>
        </button>

        {/* Tab 4: Cart Bag */}
        <button
          onClick={() => setActiveView('cart')}
          className={`relative flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
            activeView === 'cart' ? 'text-[#0c0d10] font-bold' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <ShoppingBag className={`w-5 h-5 ${activeView === 'cart' ? 'stroke-[2.5] text-[#f95700]' : ''}`} />
          {cartCount > 0 && (
            <span className="absolute top-1 right-2.5 w-4 h-4 rounded-full bg-[#f95700] text-white text-[10px] font-bold flex items-center justify-center font-mono-numbers">
              {cartCount}
            </span>
          )}
          <span className="text-[10px] tracking-tight mt-1">Bag</span>
        </button>

        {/* Tab 5: Role-based Hub / Admin / Shop / Sign In */}
        {currentUser?.role === 'admin' ? (
          <button
            onClick={() => setActiveView('admin')}
            className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
              activeView === 'admin' ? 'text-amber-600 font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <ShieldAlert className={`w-5 h-5 ${activeView === 'admin' ? 'stroke-[2.5] text-amber-600' : ''}`} />
            <span className="text-[10px] tracking-tight mt-1">Admin</span>
          </button>
        ) : currentUser?.role === 'seller' ? (
          <button
            onClick={() => setActiveView('seller_dashboard')}
            className={`flex flex-col items-center justify-center min-h-[44px] min-w-[44px] transition-colors ${
              activeView === 'seller_dashboard' ? 'text-[#123524] font-bold' : 'text-stone-500 hover:text-stone-800'
            }`}
          >
            <Store className={`w-5 h-5 ${activeView === 'seller_dashboard' ? 'stroke-[2.5] text-[#123524]' : ''}`} />
            <span className="text-[10px] tracking-tight mt-1">My Shop</span>
          </button>
        ) : (
          <button
            onClick={() => openAuthModal('seller_register')}
            className="flex flex-col items-center justify-center min-h-[44px] min-w-[44px] text-stone-500 hover:text-stone-800 transition-colors"
          >
            <Store className="w-5 h-5 text-[#f95700]" />
            <span className="text-[10px] tracking-tight mt-1">Sell</span>
          </button>
        )}
      </div>
    </nav>
  );
};
