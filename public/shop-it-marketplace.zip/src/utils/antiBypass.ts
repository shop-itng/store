/**
 * Anti-Bypass Privacy & Contact Filter
 * Enforces Shop It zero-contact policy between buyers and sellers to protect escrow safety.
 * Blocks Nigerian phone numbers (including spaced/worded), bank account numbers,
 * emails, off-platform chat mentions (WhatsApp, IG, Telegram, Opay, DM, call me).
 */

export interface AntiBypassResult {
  isViolated: boolean;
  sanitizedText: string;
  detectedViolations: string[];
  violationCount: number;
}

// Regex patterns for Nigerian and international contact evasion
const PHONE_PATTERNS = [
  // Nigerian format: 080..., 070..., 090..., 081..., +234..., 234...
  /(?:\+?234|0)[-\s.]?[789][01]\d[-\s.]?\d{3}[-\s.]?\d{4}/gi,
  // Spaced digits e.g. 0 8 0 1 2 3 4 5 6 7 8
  /\b0\s*[789]\s*[01](?:\s*\d){8}\b/gi,
  // Generic 10 to 11 consecutive or softly separated digits (e.g. account numbers or phones)
  /\b\d{3}[-\s.]?\d{3,4}[-\s.]?\d{4}\b/g,
  /\b\d{10,11}\b/g,
  // Spelled out Nigerian prefixes: "zero eight zero", "zero nine zero", "zero seven zero"
  /\b(?:zero|o)\s*(?:eight|8|seven|7|nine|9)\s*(?:zero|0|one|1)\b/gi,
];

const EMAIL_PATTERN = /\b[A-Za-z0-9._%+-]+(?:\s*@\s*|\sat\s)[A-Za-z0-9.-]+(?:\s*\.\s*|\sdot\s)[A-Z|a-z]{2,7}\b/gi;

const URL_PATTERNS = [
  /https?:\/\/[^\s]+/gi,
  /www\.[^\s]+/gi,
  /\b(?:wa\.me|t\.me|bit\.ly|tinyurl\.com|instagram\.com|tiktok\.com)\/[^\s]+/gi,
  /\b[a-zA-Z0-9-]+\.(?:com|ng|org|net|io|co|xyz|me)\b/gi,
];

const OFF_PLATFORM_KEYWORDS = [
  /\b(?:whats\s*app|whatapp|watsap|watsapp|wa\.me)\b/gi,
  /\b(?:telegram|tg\s*handle|t\.me)\b/gi,
  /\b(?:instagram|insta|ig\s*handle|ig\s*dm|dm\s*me|dm\s*on\s*ig)\b/gi,
  /\b(?:snapchat|snap\s*me)\b/gi,
  /\b(?:call\s*me|reach\s*me\s*on|text\s*me\s*on|dial\s*me|phone\s*number)\b/gi,
  /\b(?:opay|palmpay|palm\s*pay|kuda\s*bank|gtb|zenith|access\s*bank)\b/gi,
  /\b(?:send\s*to\s*my\s*account|transfer\s*to\s*my|acct\s*no|account\s*number|acct\s*num)\b/gi,
  /@([A-Za-z0-9_]{3,})/gi, // @handles
];

export function filterAntiBypass(text: string): AntiBypassResult {
  if (!text || typeof text !== 'string') {
    return {
      isViolated: false,
      sanitizedText: '',
      detectedViolations: [],
      violationCount: 0,
    };
  }

  let sanitized = text;
  const violations: string[] = [];

  // Check email
  if (EMAIL_PATTERN.test(sanitized)) {
    violations.push('Email address detected');
    sanitized = sanitized.replace(EMAIL_PATTERN, '[blocked email]');
  }

  // Check URLs
  for (const pattern of URL_PATTERNS) {
    if (pattern.test(sanitized)) {
      violations.push('External web link detected');
      sanitized = sanitized.replace(pattern, '[blocked link]');
    }
  }

  // Check phone numbers and account numbers
  for (const pattern of PHONE_PATTERNS) {
    if (pattern.test(sanitized)) {
      violations.push('Phone or account number detected');
      sanitized = sanitized.replace(pattern, '[blocked number]');
    }
  }

  // Check off-platform keywords
  for (const pattern of OFF_PLATFORM_KEYWORDS) {
    if (pattern.test(sanitized)) {
      violations.push('Off-platform payment or contact term detected');
      sanitized = sanitized.replace(pattern, '[blocked contact]');
    }
  }

  const isViolated = violations.length > 0;

  return {
    isViolated,
    sanitizedText: sanitized,
    detectedViolations: Array.from(new Set(violations)),
    violationCount: violations.length,
  };
}

/**
 * Checks text in product titles, bios, descriptions before publishing.
 */
export function validatePublicText(text: string): { isValid: boolean; reason?: string } {
  const result = filterAntiBypass(text);
  if (result.isViolated) {
    return {
      isValid: false,
      reason: `Contact info detected: ${result.detectedViolations.join(', ')}. Keep all contacts inside Shop It to protect buyer & seller escrow.`,
    };
  }
  return { isValid: true };
}
